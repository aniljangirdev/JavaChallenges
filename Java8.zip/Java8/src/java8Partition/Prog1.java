package java8Partition;

import model.Dish;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static java.util.stream.Collectors.*;

public class Prog1 {
    public static void main(String[] args) {
        List<Dish> dishes = new ArrayList<>();

        Map<Boolean, List<Dish>> map = dishes
                .stream()
                .collect(partitioningBy(Dish::isVegetarian));

        Map<Boolean, Map<Dish.Type, List<Dish>>> list = dishes
                .stream()
                .collect(partitioningBy(Dish::isVegetarian,
                        groupingBy(Dish::getType)));

        Map<Boolean, Dish> maps = dishes
                .stream()
                .collect(partitioningBy(Dish::isVegetarian,
                        collectingAndThen(maxBy(Comparator.comparingInt(Dish::getCalories)),
                                Optional::get)));

        Map<Boolean, Long> map3 = dishes
                .stream()
                .collect(Collectors.partitioningBy(Dish::isVegetarian,
                        Collectors.counting()));

        int total = dishes
                .stream()
                .collect(reducing(0, Dish::getCalories, Integer::sum));


        ArrayList<Dish> collect = dishes
                .stream()
                .collect(ArrayList::new,
                        List::add,
                        List::addAll);

    }

    private static boolean isPrime(int candidate){
        int candidateRoot = (int) Math.sqrt(candidate);
        return IntStream
                .rangeClosed(2, candidateRoot)
                .noneMatch(i -> candidate % i == 0);
    }

    private static void partitionPrime(int n){
        IntStream.rangeClosed(2, n)
                .boxed()
                .collect(Collectors.partitioningBy(Prog1::isPrime));
    }
}
