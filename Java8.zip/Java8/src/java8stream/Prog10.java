package java8stream;

import java.util.function.IntSupplier;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Prog10 {
    public static void main(String[] args) {
        /* using generate*/
        Stream.generate(Math::random)
                .limit(5)
                .forEach(System.out::println);

        /* create fibo using generate*/
        IntSupplier intSupplier = new IntSupplier() {
            private int previous = 0;
            private int current = 1;

            @Override
            public int getAsInt() {
                int oldPre = this.previous;
                int nextVal = previous + this.current;
                this.previous = this.current;
                this.current = nextVal;
                return oldPre;
            }
        };

        IntStream.generate(intSupplier).limit(10)
                .forEach(System.out::println);

    }

}
