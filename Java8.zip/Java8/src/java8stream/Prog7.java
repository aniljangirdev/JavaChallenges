package java8stream;

import model.Dish;

import java.util.*;
import java.util.stream.IntStream;

public class Prog7 {
    public static void main(String[] args) {
        /* numeric ranges with range() and rangeClosed() */
        long count = IntStream.range(1, 100)
                .filter((n) -> n % 2 == 0)
                .count();

        /* convert primitive stream to normal stream*/
        /* IntStream to Stream<Integer> */
        IntStream range = IntStream.range(1, 100);
        range.boxed();// convert numeric stream to stream

        // convert max element from stream
        List<Dish> dishes = new ArrayList<>();
        OptionalInt maxDish = dishes
                .stream()
                .mapToInt(Dish::getCalories)
                .max();

        int a = 3, b = 4;
        double sqrt = Math.sqrt(a * a + b * b);
        System.out.println(sqrt);
    }
}
