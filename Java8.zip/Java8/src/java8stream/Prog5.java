package java8stream;

import model.Dish;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class Prog5 {
    public static void main(String[] args) {
        /* matching with stream API 8*/
        List<Dish> menu = Arrays.asList(
                new Dish("pork", false, 800, Dish.Type.MEAT),
                new Dish("beef", false, 700, Dish.Type.MEAT),
                new Dish("chicken", false, 400, Dish.Type.MEAT),
                new Dish("french fries", true, 530, Dish.Type.OTHER),
                new Dish("rice", true, 350, Dish.Type.OTHER),//
                new Dish("season fruit", true, 120, Dish.Type.OTHER),//
                new Dish("pizza", true, 550, Dish.Type.OTHER),
                new Dish("prawns", false, 300, Dish.Type.FISH),//
                new Dish("salmon", false, 450, Dish.Type.FISH));

        /* match at least one elements*/
        boolean isHaveVagiterian = menu
                .stream()
                .anyMatch(Dish::isVegetarian);

        boolean isHealthy = menu
                .stream()
                .allMatch((dish -> dish.getCalories() < 1000));

        /* with noMatch*/
        boolean isHeanthy = menu
                .stream()
                .noneMatch(dish -> dish.getCalories() >= 1000);

        /* with findAny*/
        Optional<Dish> any = menu
                .stream()
                .filter(Dish::isVegetarian)
                .findAny();

        menu
                .stream()
                .filter(Dish::isVegetarian)
                .findAny()
                .ifPresent((dish -> System.out.println(dish.getName())));

        /* find first elements */
        // find first square that's divide by 3 from list of numbers
        List<Integer> integers = List.of(1, 2, 4, 5, 7, 9);
        Integer result = integers
                .stream()
                .map((i)-> i* i)
                .filter((i) -> i % 3 == 0)
                .findFirst().get();

        /* reduce*/
        /* sum of element from list*/
        int sum = integers
                .stream()
                .reduce(0, Integer::sum);
        System.out.println("sum " + sum);

        /* reduce*/
        /* calculate the some of all calories in the menu*/

    }
}
