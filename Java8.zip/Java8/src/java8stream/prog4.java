package java8stream;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class prog4 {
    public static void main(String[] args) {
        /* return list of the square of each number from list of number */
        List<Integer> integers = List.of(1, 2, 4, 5, 7, 9);

        /* find list of square */
        List<Integer> listOfSquare = integers.stream().map((i) -> i * i).collect(Collectors.toList());

        System.out.println(listOfSquare);

        /* given two list of numbers, how would you return all pairs of numbers */
        List<Integer> list1 = List.of(1, 2, 3);
        List<Integer> list2 = List.of(3, 4);

        List<int[]> pair = findPair(list1, list2);
        for (int[] ints : pair) {
            System.out.print(Arrays.toString(ints));
        }

        System.out.println();

        List<int[]> pairWithStream = findPairWithStream(list1, list2);
        for (int[] ints : pairWithStream) {
            System.out.print(Arrays.toString(ints));
        }

        System.out.println();


        List<int[]> pairWithDivideBy3 = findPairWithDivideBy3(list1, list2);
        for (int[] ints : pairWithDivideBy3) {
            System.out.print(Arrays.toString(ints));
        }

    }

    /* with traditional way*/
    static List<int[]> findPair(List<Integer> list1, List<Integer> list2) {
        List<int[]> result = new ArrayList<>();
        for (int i = 0; i < list1.size(); i++) {
            for (int j = 0; j < list2.size(); j++) {
                int[] val = new int[]{list1.get(i), list2.get(j)};
                result.add(val);
            }
        }
        return result;
    }

    /* with stream API*/
    static List<int[]> findPairWithStream(List<Integer> list1, List<Integer> list2) {
        return list1
                .stream()
                .flatMap((i) -> list2
                        .stream()
                        .map((j) -> new int[]{i, j}))
                .collect(Collectors.toList());
    }

    /* return only pair whose sum os divisible by 3?*/
    static List<int[]> findPairWithDivideBy3(List<Integer> list1, List<Integer> list2) {
        return list1
                .stream()
                .flatMap((i) -> list2
                        .stream()
                        .filter((j) -> {
                            int sum = i + j;
                            return sum % 3 == 0;
                        })
                        .map((j) -> new int[]{i, j}))
                .collect(Collectors.toList());
    }
}
