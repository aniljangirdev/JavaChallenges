package java8stream;

import model.Dish;

import java.util.List;

public class Prog6 {
    public static void main(String[] args) {
        /* reduce min*/
        List<Integer> integers = List.of(1, 2, 4, 5, 7, 9);
        Integer reduceMin = integers.stream()
                .reduce(0, Integer::min);

        Integer reduceMax = integers.stream()
                .reduce(0, Integer::max);

        // count no of dishes in a stream using map and reduce method

    }

    static int countNoOfDishes(List<Dish> integers){
        return integers
                .stream()
                .map(dish -> 1)
                .reduce(0, Integer::sum);
    }

    static long countNoOfDishes1(List<Dish> dishes){
        return dishes
                .stream()
                .count();
    }


}
