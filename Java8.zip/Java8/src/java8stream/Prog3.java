package java8stream;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Prog3 {
    public static void main(String[] args) {
        List<String> words = List.of("Welcome", "Hello", "world");
        /*find list of all the unique characters for a list of words*/

        List<String> collect = words
                .stream()
                .map((word -> word.split("")))
                .flatMap(Arrays::stream)
                .distinct()
                .collect(Collectors.toList());
        System.out.println(collect);

    }
}
