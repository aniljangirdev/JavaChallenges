package java8stream;

import model.Dish;

import java.util.*;
import java.util.stream.Collectors;

public class Prog1 {
    public static void main(String[] args) {

        List<Dish> menu = Arrays.asList(
                new Dish("pork", false, 800, Dish.Type.MEAT),
                new Dish("beef", false, 700, Dish.Type.MEAT),
                new Dish("chicken", false, 400, Dish.Type.MEAT),
                new Dish("french fries", true, 530, Dish.Type.OTHER),
                new Dish("rice", true, 350, Dish.Type.OTHER),//
                new Dish("season fruit", true, 120, Dish.Type.OTHER),//
                new Dish("pizza", true, 550, Dish.Type.OTHER),
                new Dish("prawns", false, 300, Dish.Type.FISH),//
                new Dish("salmon", false, 450, Dish.Type.FISH));

        List<String> lowCalryDishesName = findLowCalryDishesName(menu);
        System.out.println(lowCalryDishesName);

        Map<Dish.Type, List<Dish>> typeListMap = filterByType(menu);
        System.out.println(typeListMap);

        List<String> threeHighCaloriesDishName = findThreeHighCaloriesDishName(menu);
        System.out.println(threeHighCaloriesDishName);
    }

    /* Dishes group by type */
    static Map<Dish.Type, List<Dish>> filterByType(List<Dish> dishes){
        return dishes
                .stream()
                .collect(Collectors.groupingBy(Dish::getType));
    }

    static List<String> findLowCalryDishesName(List<Dish> dishes){
        return dishes
                .stream()
                .filter((d) -> d.getCalories() < 400)
                .sorted(Comparator.comparing(Dish::getCalories))
                .map(Dish::getName)
                .collect(Collectors.toList());
    }

    static List<String> findThreeHighCaloriesDishName(List<Dish> dishes){
        return dishes
                .stream()
                .sorted(Comparator.comparing(Dish::getCalories).reversed())
                .limit(3)
                .map(Dish::getName)
                .collect(Collectors.toList());
    }

    static long findCountByHighestCalories(List<Dish> dishes){
        return dishes
                .stream()
                .filter((d) -> d.getCalories() > 300)
                .distinct()
                .limit(3)
                .count();
    }

}
