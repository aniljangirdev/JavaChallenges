package java8stream;

import java.util.List;
import java.util.stream.Collectors;

public class Prog2 {
    public static void main(String[] args) {
        /*find list of number of characters for each word*/
        List<String> strings = List.of("Welcome","Hello","world");

        List<Integer> numberOfWord = strings
                .stream()
                .map(String::length)
                .collect(Collectors.toList());

        System.out.println(numberOfWord);
    }
}
