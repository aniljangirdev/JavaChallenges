package java8stream;

import java.util.Arrays;
import java.util.stream.Stream;

public class prog9 {
    public static void main(String[] args) {
        /* create fibonacci tupple series*/
        int[] start = new int[]{0,1};
        Stream.iterate(start, (arr) -> new int[]{arr[1], arr[0] + arr[1]})
                .limit(10)
                .forEach((arr) -> System.out.println(Arrays.toString(arr)));

        /* with 2 argument as predicate*/
        Stream.iterate(0, no -> no < 100, no -> no + 4)
                .forEach(System.out::println);

        /* same with takeWhile() instead of filter()*/
        Stream.iterate(0, no -> no + 4)
                .takeWhile(i -> i < 100)
                .forEach(System.out::println);



    }
}
