package java8stream;

import java.io.FileWriter;
import java.io.IOException;
import java.net.URI;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.ClientInfoStatus;
import java.util.Arrays;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class prog8 {
    public static void main(String[] args) throws IOException {
        Stream.of("Welcome", "Java 8")
                .map(String::toUpperCase)
                .forEach(System.out::println);

        /* with stream Nullable*/

        Optional<String> stream = Optional.ofNullable(System.getProperty("home"));
        int[] input = {1, 2, 3};
        int sum = Arrays.stream(input).sum();

        /* find number of unique words*/
        long l = noOfUniqueWord();
        System.out.println("count : "+ l);

        Stream.iterate(0,i-> i  + 2)
                .limit(10)
                .forEach(System.out::println);

    }

    static long noOfUniqueWord() throws IOException {
        try (Stream<String> lines = Files.lines(Paths.get("./temp/test.txt"),
                StandardCharsets.UTF_8)) {
            return lines
                    .flatMap((line) -> {
                        String[] split = line.split(" ");
                        System.out.println(Arrays.toString(split));
                        return Arrays.stream(split);
                    })
                    .peek(System.out::println)
                    .distinct()
                    .count();
        }
    }
}
