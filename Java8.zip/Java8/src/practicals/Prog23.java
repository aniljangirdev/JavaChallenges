package practicals;

import java.util.Arrays;

public class Prog23 {
    public static void main(String[] args) {
        /*Given two sorted arrays and a number x,
        find the pair whose sum is closest to x and the pair has an element from each array. */
        int[] ar1 = {1, 4, 5, 7};// i = 2
        int[] ar2 = {10, 20, 30, 40}; // j = 3
        int target = 32;
        int[] minimum = findMinimum(ar1, ar2, target);
        System.out.println(Arrays.toString(minimum));
    }

    private static int[] findMinimum(int[] ar1, int[] ar2, int target) {
        int[] ans = new int[]{-1, -1};
        int diff = Integer.MAX_VALUE;
        int start = 0;
        int end = ar2.length - 1;

        while (start < ar1.length && end >= 0) {
            int sum = ar1[start] + ar2[end];
            int currentDiff = Math.abs(sum - target);

            if (currentDiff < diff) {
                diff = currentDiff;
                ans[0] = ar1[start];
                ans[1] = ar2[end];
            } else if (sum < target) {
                start++;
            } else {
                end--;
            }
        }
        return ans;
    }


}
