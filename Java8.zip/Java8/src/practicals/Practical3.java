package practicals;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class Practical3 {
    public static void main(String[] args) {
        /* Given an integer array nums, return true if any value appears at least twice in the array,
         and return false if every element is distinct.*/
        List<Integer> numbers = Arrays.asList(1, 2, 3, 41, 5, 22, 50, 5, 23, 50, 4, 5);

        Predicate<Integer> integerPredicate = (i) -> Collections.frequency(numbers, i) > 1;

        numbers
                .stream()
                .filter(integerPredicate)
                .collect(Collectors.toSet())
                .forEach(System.out::println);
    }
}
