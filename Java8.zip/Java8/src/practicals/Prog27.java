package practicals;

public class Prog27 {
    public static void main(String[] args) {
        Runnable runnable = () -> {
            int a = 10;
            System.out.println(a);
        };

        doSomething((Task) () -> System.out.println("test"));



    }

    static void doSomething(Runnable runnable){
        runnable.run();
    }

    static void doSomething(Task task){
        task.execute();
    }

}

interface Task{
    public void execute();
}
