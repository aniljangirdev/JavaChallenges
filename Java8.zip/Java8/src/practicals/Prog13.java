package practicals;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Prog13 {
    public static void main(String[] args) {
        /**  Given a list of integers, sort all the values present in it in descending order using Stream functions?*/
        List<Integer> integerList = Arrays.asList(22, 1, 41, 5, 22, 50, 5, 23, 50, 4, 5);
        integerList
                .stream()
                .sorted(Collections.reverseOrder())
                .distinct()
                .forEach(System.out::println);



    }
}
