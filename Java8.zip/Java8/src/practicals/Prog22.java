package practicals;

import java.util.*;

public class Prog22 {
    public static void main(String[] args) {
        /*
        Given an int array nums and an int target.
        Find two integers in nums such that the sum is closest to target.
        * */
//        int[] nums = new int[]{-1, 2, 1, -4}; // 4, 3, 2, 1
        int[] nums = new int[]{1, 2, 3, 4, 5};
        int target = 4;
        int[] ans = findNearest(nums, target);
        System.out.println(Arrays.toString(ans));
    }

    private static int[] findNearest(int[] nums, int target) {
        int start = 0;
        int end = nums.length - 1;
        int difference = Integer.MAX_VALUE;
        int[] res = new int[2];
        while (start < end) {
            int sum = nums[start] + nums[end];
            if (Math.abs(target - sum) < difference) {
                difference = Math.abs(target - sum);
                res[0] = nums[start];
                res[1] = nums[end];
            }
            if (sum < target) {
                start++;
            } else {
                end--;
            }
        }
        return res;
    }
}
