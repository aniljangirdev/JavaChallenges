package practicals;

import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Prog29 {
    /*find factorial*/
    public static void main(String[] args) {
        int no = 5;
        int factorial = factorial(no);
        int factorialRecursive = factorialRecursive(no);
        int factorialStream = factorialStream(no);
        int sumStream = findSumRecursive(no);
        System.out.println(factorial);
        System.out.println(factorialRecursive);
        System.out.println(factorialStream);
        System.out.println(sumStream);
    }

    private static int factorial(int no) {
        int fact = 1;
        for (int i = 1; i <= no; i++) { //1, 2, 3, 4 , 5
            fact  *= i;
        }
        return fact;
    }
    private static int factorialRecursive(int no){ // 5, 4, 3 ,2, 1
//        return no == 1 ? 1 : no * factorialRecursive(no - 1);
        return (int)factorialHelper(1, no);
    }

    private static int factorialStream(int no){
        return IntStream.rangeClosed(1, no)
                .reduce(1, (a, b) -> a * b);
    }

    private static long factorialHelper(long acc, long n){
        return n == 1 ? acc : factorialHelper(acc * n, n - 1);
    }

    private static int findSumRecursive(int no){
        return (int) sumOfNumberHelper(0, no);
    }

    private static long sumOfNumberHelper(int ans ,int no){
        return no == 0 ? ans : sumOfNumberHelper(ans + no, no - 1);
    }

}
