package practicals;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.stream.IntStream;

public class Prac4 {
    public static void main(String[] args) {
        /*Write a Java 8 program to sort an array and then convert the sorted array into Stream?*/
        int arr[] = {99, 55, 203, 99, 4, 91};

        Arrays.parallelSort(arr);

        Arrays.stream(arr)
                .forEach(System.out::println);

    }
}
