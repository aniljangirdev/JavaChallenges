package practicals;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Prog8 {
    public static void main(String[] args) {
        /* Given a String, find the first non-repeated character in it using Stream functions*/
        String stringObj = "eetclode";
        char firstNoRepeat = findFirstNoRepeat(stringObj);
        System.out.println(firstNoRepeat);
        findFirstNoRepeat1(stringObj);
    }

    static char findFirstNoRepeat(String stringObj) {
        for (int i = 0; i < stringObj.length(); i++) {
            boolean isFlag = true;
            for (int j = i + 1; j < stringObj.length(); j++) {
                if (stringObj.charAt(i) == stringObj.charAt(j)) {
                    isFlag = false;
                } else {
                    isFlag = true;
                    break;
                }
            }
            if (isFlag)
                return stringObj.charAt(i);
        }
        return 0;
    }

    /* using hashmap*/
    static char findFirstNoRepeat1(String s) {
        HashMap<Character, Integer> map = new HashMap<>();
        for(int i = 0; i < s.length(); i++){
            char c = s.charAt(i);
            map.put(c, map.getOrDefault(c, 0 )  +1);
        }
        for(int i = 0; i < s.length(); i++){
            if(map.get(s.charAt(i)) == 1)
                return s.charAt(i);
        }
        return 0;
    }
    
    /* using strem API*/
    public char findFirstNoRepeatWithStream(String str) {
        return str
                .chars()
                .mapToObj((i) -> Character.toLowerCase((char) i))
                .collect(Collectors.groupingBy(
                        Function.identity(),
                        LinkedHashMap::new,
                        Collectors.counting()))
                .entrySet()
                .stream()
                .filter((k) -> k.getValue() == 1)
                .map(Map.Entry::getKey)
                .findFirst()
                .get();
    }
}