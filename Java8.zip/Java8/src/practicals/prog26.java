package practicals;

import model.Transaction;

import java.lang.reflect.Array;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class prog26 {
    public static void main(String[] args) {
        /* immutable list */
        List<String> test = List.of("test", "test");

        /* immutable Set with uniqueness*/
        Set.of("test1", "test2");

        /*Immutable Map*/
        Map<String, Integer> stringIntegerMap = Map.of( "jangir", 20,"anil", 10);

        /*Immutable with entries*/
        Map<String, Integer> stringIntegerMap1 = Map.ofEntries(Map.entry("anil", 10), Map.entry("jangir", 20));

        List<Transaction> transactions = new ArrayList<>();
        transactions.add(new Transaction());
        transactions.add(new Transaction());
        transactions.add(new Transaction());
        for (int i = 0; i < transactions.size(); i++) {
            if (!Objects.isNull(transactions.get(i).getCurrency())) {
                transactions.remove(transactions.get(i));
            }
        }

        transactions
                .removeIf((Objects::nonNull));

        stringIntegerMap
                .entrySet()
                .stream()
                .sorted(Map.Entry.comparingByKey())
                .forEachOrdered(System.out::println);

        stringIntegerMap
                .computeIfAbsent("anil", String::length);

        stringIntegerMap.remove("anil", 10);

        ConcurrentHashMap<String, Long> map = new ConcurrentHashMap<>();
        long threadHold = 1L;
        Optional<Long> aLong = Optional
                .of(map.reduceValues(threadHold, Long::max));
    }
}
