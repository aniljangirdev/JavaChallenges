package practicals;

import java.util.stream.IntStream;

public class Prog12 {
    public static void main(String[] args) {
        /*Java 8 program to perform cube on list elements and filter numbers greater than 50.*/
        IntStream
                .iterate(2, (i) -> i *i * i)
                .limit(10)
                .forEach(System.out::println);
    }
}
