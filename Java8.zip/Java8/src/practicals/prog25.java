package practicals;

public class prog25 {
    public static void main(String[] args) {

    }
}
