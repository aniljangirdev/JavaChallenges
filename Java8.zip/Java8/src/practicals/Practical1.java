package practicals;

import model.TTransaction;
import model.Trader;

import java.util.*;
import java.util.stream.Collectors;

public class Practical1 {
    public static void main(String[] args) {
        /* trade executor trasanction*/
        /*
         * 1. find transactions in the year 2011 and short them by values(small to high);
         * 2. What are the unique cities where traders work?
         * 3. Find all traders form cambridge and sort them by name.
         * 4. Return a string of all traders' name sorted alphabetically
         * 5. Are any traders based in Milan?
         * 6. Print the values of all transactions from the traders living in cambridge?
         * 7. what's the highest value of all the transactions?
         * 8. Find transaction with the smallest value.
         * */

        Trader raoul = new Trader("Raoul", "Cambridge");
        Trader mario = new Trader("Mario", "Milan");
        Trader alan = new Trader("Alan", "Cambridge");
        Trader brian = new Trader("Brian", "Cambridge");
        List<TTransaction> transactions = Arrays.asList(
                new TTransaction(brian, 2011, 300),
                new TTransaction(raoul, 2012, 1000),
                new TTransaction(raoul, 2011, 400),
                new TTransaction(mario, 2012, 710),
                new TTransaction(mario, 2012, 700),
                new TTransaction(alan, 2012, 950)
        );


        transaction1(transactions);
        transaction2(transactions);
        transaction3(transactions); //?
        transaction4(transactions);
        transaction5(transactions);
        transaction6(transactions);
        transaction7(transactions);
        transaction8(transactions);

    }

    private static Optional<TTransaction> transaction8(List<TTransaction> transactions) {
        return transactions
                .stream()
                .min(Comparator.comparing(TTransaction::getValue));
//                .reduce((t1, t2) -> t1.getValue() < t2.getValue() ? t1 : t2);

    }

    private static Optional<Integer> transaction7(List<TTransaction> transactions) {
        return transactions
                .stream()
                .map(TTransaction::getValue)
                .reduce(Integer::max);
    }

    private static void transaction6(List<TTransaction> transactions) {
         transactions
                .stream()
                .filter((transaction -> transaction.getTrader().getCity().equals("Cambridge")))
                .map(TTransaction::getValue)
                .forEach(System.out::println);
    }

    /* 4 */
    private static boolean transaction5(List<TTransaction> transactions) {
        return transactions
                .stream()
                .anyMatch((transaction -> transaction.getTrader().getCity().equals("Milan")));
    }

    /* 4 */
    private static String transaction4(List<TTransaction> transactions) {
        return transactions
                .stream()
                .map((transaction -> transaction.getTrader().getName()))
                .distinct()
                .sorted()
//                .reduce("", (a, b) -> a + b);
        // reduce used where need to combine multiple values
        // single
                .collect(Collectors.joining());
    }

    /* 3 */
    private static List<Trader> transaction3(List<TTransaction> transactions) {
        return transactions
                .stream()
                .map(TTransaction::getTrader)
                .filter((trader -> trader.getCity().equals("Cambridge")))
                .distinct()
                .sorted(Comparator.comparing(Trader::getName))
                .collect(Collectors.toList());
    }

    /* 2 */
    private static Set<String> transaction2(List<TTransaction> transactions) {
        return transactions
                .stream()
                .map((transaction -> transaction.getTrader().getCity()))
                .collect(Collectors.toSet());
    }

    /* 1 */
    static List<TTransaction> transaction1(List<TTransaction> transactions) {
        return transactions
                .stream()
                .filter((transaction) -> transaction.getYear() == 2011)
                .sorted(Comparator.comparing(TTransaction::getValue))
                .collect(Collectors.toList());
    }

}
