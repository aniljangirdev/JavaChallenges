package practicals;

import model.Employee;

import java.text.ParseException;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class Prog30 {
    public static void main(String[] args) throws ParseException {
        /* sort by employee salary*/
        List<Employee> employees = List.of();
        employees
                .stream()
                .sorted(Comparator.comparingDouble(Employee::getSalary))
                .collect(Collectors.toList());
    }

    }
