package practicals;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Prog20 {
    public static void main(String[] args) {
        /*FindEvenNumberInMapOfList */
        List<Integer> list1 = Arrays.asList(2,4,5,7,9);
        List<Integer> list2 = Arrays.asList(12,13,15,16,17,19);
        List<Integer> list3 = Arrays.asList(22, 23, 24, 27, 29);

        Set<Integer> collect = Stream.of(list1, list2, list3)
                .flatMap(Collection::stream)
                .filter(i -> i % 2 == 0)
                .collect(Collectors.toSet());

        System.out.println(collect);

    }
}
