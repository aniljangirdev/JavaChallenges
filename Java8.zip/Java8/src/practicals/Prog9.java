package practicals;

import model.Dish;
import model.Employee;

import java.math.BigDecimal;
import java.util.*;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class Prog9 {
    public static void main(String[] args) {
        /* increase all employee salary by 10% whose salary is < 20000*/

        List<Employee> employees = new ArrayList<>();
        Employee employee1 = new Employee();
        employee1.setId(1);
        employee1.setName("Anil");
        employee1.setSalary(10000.0);
        employees.add(employee1);

        Predicate<Employee> employeePredicate = (emp) -> emp.getSalary() < 20000;

        Function<Employee, Employee> employeeEmployeeFunction =
                (employee) -> {
                    double increment = (employee.getSalary() * 10) / 100;
                    employee.setSalary(employee.getSalary() + increment);
                    return employee;
                };

        Map<Integer, Double> collect = employees
                .stream()
                .filter(employeePredicate)
                .map(employeeEmployeeFunction)
                .collect(Collectors.toMap(Employee::getId,
                        Employee::getSalary));

        System.out.println(collect);


    }
}
