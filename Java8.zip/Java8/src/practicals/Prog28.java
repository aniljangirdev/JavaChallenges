package practicals;

import java.util.Arrays;

public class Prog28 {
    public static void main(String[] args) {
        int[] input = new int[]{2, 4, 6, 11, 5, 15};
        int[] ints = startWith1(input);
        System.out.println(Arrays.toString(ints));
    }

    private static int[] startWith1(int[] input) {
        return Arrays.stream(input)
                .filter((i) -> {
                    String str = String.valueOf(i);
                    return str.startsWith("1");
                })
                .toArray();
    }
}
