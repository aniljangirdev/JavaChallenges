package practicals;

import java.math.BigInteger;

public class Prog33 {
    public static void main(String[] args) {

        int no = 12345;
        // divide by 10
        // take reminder and add in to new value
       no =  getTotal(no);
        System.out.println(no);
    }

    private static int getTotal(int no) {
        int total = 0;
        int start = 0;
        while (start < no) {
            int rem = no % 10; // 6
            no = no / 10; //
            total += rem;
        }
        return total;
    }



}
