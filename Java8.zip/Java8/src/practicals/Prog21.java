package practicals;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class Prog21 {
    public static void main(String[] args) {
        List<Integer> list = Arrays.asList(12, 13, 15, 16, 17, 19, 22, 23, 24, 16, 27, 29);
        Integer max = list.stream()
                .max(Comparator.comparingInt(Integer::valueOf)).get();

        max = list
                .stream()
                .mapToInt(Integer::intValue)
                .max().orElse(0);

        max =
                list
                        .stream()
                        .reduce(0, Math::max);

        max = list
                .stream()
                .max(Comparator.comparing(Integer::intValue)).get();

        System.out.println(max);

    }
}
