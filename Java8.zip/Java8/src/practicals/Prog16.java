package practicals;

import java.util.stream.LongStream;

public class Prog16 {
    public static void main(String[] args) {
        int no = 500;
        Accumulator accumulator = new Accumulator();
        LongStream longStream = LongStream.rangeClosed(1, no);
        longStream
                .parallel()
                .forEach(accumulator::add);
        long total = accumulator.total;
        System.out.println(total);
    }
}

class Accumulator {
    public long total = 0;

    public void add(long value) {
        total += value;
    }
}
