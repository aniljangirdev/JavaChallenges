package practicals;

public class Prog35 {
    public static void main(String[] args) {
        /* print fibonacci series/
         */
//        eg. 0, 1, 1, 2, 3, 5, 8, 13, 21

        int no = 10;
        findFibonacciRecursive(no);

    }


    private static void findFibonacci(int no) {
        int no1 = 0;
        int no2 = 1;
        for (int i = 0; i < no; i++) {
            System.out.println(no1 + " ");

            int no3 = no1 + no2; // 1
            no1 = no2;
            no2 = no3;
        }
    }

    private static void findFibonacciRecursive(int no) {
        recursive(no, 0, 0, 1);
    }

    private static void recursive(int no, int start, int no1, int no2) {
        if (start >= no) {
            return;
        }
        System.out.println(no1); //0
        int no3 = no1 + no2; //1
        no1 = no2;// 1
        no2 = no3;//1

        start++;

        recursive(no, start, no1, no2);
    }

}
