package practicals;

import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Prog11 {
    public static void main(String[] args) {

        IntStream
                .iterate(0, i -> i + 1)
                .limit(100)
                .mapToObj(String::valueOf)
                .filter((str) -> str.startsWith("1"))
                .collect(Collectors.toList())
                .forEach(System.out::println);

    }
}
