package practicals;

import model.Dish;
import model.PPerson;
import model.Person;

import java.lang.reflect.Array;
import java.util.*;
import java.util.concurrent.BlockingDeque;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.DoubleAdder;
import java.util.function.Predicate;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Prog31 {
    public static void main(String[] args) {
        String str = "microservices in action";
        Map<Character, Integer> collect = str.chars().mapToObj((i) -> (char) i).filter(Predicate.not(Character::isWhitespace)).collect(Collectors.toMap(s -> s, p -> 1, Integer::sum, LinkedHashMap::new));
        System.out.println(collect);

        Map<String, String> map = Map.ofEntries(Map.entry("test1", "test"), Map.entry("test2", "test2"));
        ConcurrentHashMap<String, String> stringStringConcurrentHashMap = new ConcurrentHashMap<>(map);
        int[] evenNumbers = new int[10];
        Arrays.setAll(evenNumbers, (i) -> i * 2);
        System.out.println(Arrays.toString(evenNumbers));
        int[] ones = new int[10];
        Arrays.fill(ones, 1);
        Arrays.parallelPrefix(ones, Integer::sum);
        System.out.println(Arrays.toString(ones));

        List<Dish> dishes = new ArrayList<>();
        dishes.stream()
                .mapToInt(Dish::getCalories).sum();
        Dish dish = dishes.stream()
                .reduce((d1, d2) -> d1.getCalories() > d2.getCalories()
                        ? d1 : d2).get();


        List<PPerson> personList = new ArrayList<>();
        List<String> collect1 = personList
                .stream()
                .map(PPerson::getHobbies)
                .flatMap(Collection::stream)
                .collect(Collectors.toList());

        personList
                .stream()
                .max(Comparator.comparingInt(PPerson::getAge));






    }


    static <T> List<T> emptyList() {
        return new ArrayList<>();
    }

}


