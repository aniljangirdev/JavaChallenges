package practicals;

public class Prog34 {
    public static void main(String[] args) {
        // find second largest elements
        int[] ints = new int[]{3,5, 7,4,8};
        int secondLargest = findSecondLargest(ints);
        System.out.println("second largest element: "+ secondLargest);

    }

    private static int findSecondLargest(int[] ints){
        int firstLargest = Integer.MIN_VALUE;
        int secondLargest = Integer.MIN_VALUE;
        for (int anInt : ints) {
            if (firstLargest < anInt) {
                secondLargest = firstLargest;
                firstLargest = anInt;
            } else if (secondLargest < anInt && anInt != firstLargest) {
                secondLargest = anInt;
            }
        }
        return secondLargest;

    }

}
