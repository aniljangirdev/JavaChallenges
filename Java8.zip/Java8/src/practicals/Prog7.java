package practicals;

import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class Prog7 {
    public static void main(String[] args) {
        /*How to find duplicate elements in a given integers list in java using Stream functions?*/
        List<Integer> integerList = Arrays.asList(1, 22, 1, 41, 5, 22, 50, 5, 23, 50, 4, 5);
        Predicate<Integer> integerPredicate = i -> Collections.frequency(integerList, i) > 1;
        integerList
                .stream()
                .filter(integerPredicate)
                .distinct()
                .sorted()
                .forEach(System.out::println);

        /*Given a list of integers, find the maximum value element present in it using Stream functions?*/

        integerList
                .stream()
                .max(Comparator.naturalOrder())
                .get();


    }
}
