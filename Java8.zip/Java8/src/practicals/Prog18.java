package practicals;

import java.util.stream.Stream;

public class Prog18 {
    public static void main(String[] args) {
        int sum = Stream.iterate(1, (i) -> i + 1)
                .limit(500)
                .parallel()
                .reduce(0, Integer::sum);

        System.out.println(sum);
    }
}
