package practicals;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class Prog10 {
    public static void main(String[] args) {
        /*  Given a String, find the first non-repeated character in it using Stream functions*/
        String input = "leetcode";
        char result = firstUniqChar(input);
        System.out.println(result);

        char c = firstUniqCharMap(input);
        System.out.println(c);

        char ch = firstUniqCharStream(input);
        System.out.println(ch);

    }

    /* using stream API*/
    private static char firstUniqCharStream(String s) {
        return s
                .chars()
                .mapToObj((ch) -> (char) ch)
                .collect(Collectors.groupingBy(Function.identity(), LinkedHashMap::new, Collectors.counting()))
                .entrySet()
                .stream()
                .filter((map) -> map.getValue() == 1)
                .map(Map.Entry::getKey)
                .findFirst()
                .get();
    }

    /* using HashMap */
    private static char firstUniqCharMap(String s) {
        Map<Character, Integer> map = new LinkedHashMap<>();
        for (char ch : s.toCharArray()) {
            map.put(ch, map.getOrDefault(ch, 0) + 1);
        }

        for (Character character : map.keySet()) {
            if (map.get(character) == 1) {
                return character;
            }
        }
        return 0;
    }

    private static char firstUniqChar(String s) {
        // edge case
        if (s == null || s.length() == 0) {
            return 0;
        }

        char[] ch = s.toCharArray();
        for (int i = 0; i < ch.length; i++) {
            boolean flag = false;
            for (int j = i + 1; j < ch.length; j++) {
                if (ch[i] == ch[j]) {
                    flag = true;
                    break;
                }
            }
            if (!flag) {
                return ch[i];
            }
        }
        return 0;
    }
}
