package practicals;

public class Prog32 {
    public static void main(String[] args) {
        A.foo();
    }
}

class A{
    public static void foo(){
        System.out.println("test foo!");
    }

//    public void foo(){

//    }
}

