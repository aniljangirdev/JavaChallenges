package practicals;

public class Peog19 {
    public static void main(String[] args) {
        String input = "dad test  dsdsw eww ";
        int i = countWordInteratively(input);
        System.out.println(i);
    }

    private static int countWordInteratively(String s){
        int counter = 0;
        boolean lastSpace = true;
        for (char c : s.toCharArray()) {
            if (Character.isWhitespace(c)) {
                lastSpace = true;
            } else {
                if (lastSpace) counter++;
                lastSpace = false;
            }
        }
        return counter;
    }
}
