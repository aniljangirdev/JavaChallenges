package practicals;

public class pract5 {
    public static void main(String[] args) {
        boolean flag = (false || false || false);
        System.out.println(flag);
    }
}
