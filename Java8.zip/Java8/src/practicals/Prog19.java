package practicals;

import java.security.cert.CollectionCertStoreParameters;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Prog19 {
    public static void main(String[] args) {
        List<Integer> integers = Arrays.asList(1, 2, 3,4, 4, 5, 6, 6, 7);

        /* findDuplicateInList using hashmap*/
        List<Integer> collect = integers
                .stream()
                .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()))
                .entrySet()
                .stream()
                .filter((entry) -> entry.getValue() > 1)
                .map(Map.Entry::getKey)
                .collect(Collectors.toList());
        System.out.println(collect);

        /* findDuplicateInList using HashSet*/
        Set<Integer> collect1 = integers
                .stream()
                .filter((i) -> Collections.frequency(integers, i) > 1)
                .collect(Collectors.toSet());
        System.out.println(collect1);

    }
}
