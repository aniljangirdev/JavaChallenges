package practicals;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Prog5 {
    public static void main(String[] args) {
        /*How to use map to convert object into Uppercase in Java 8?*/
        List<String> list1 = Arrays.asList("aaa", "bbb", "ccc","ddd" , "eee");
        list1.stream().map(String::toUpperCase)
                .collect(Collectors.toList())
                .forEach(System.out::println);
    }
}
