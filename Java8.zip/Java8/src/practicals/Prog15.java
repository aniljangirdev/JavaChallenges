package practicals;

import java.util.stream.IntStream;

public class Prog15 {
    public static void main(String[] args) {
        /* find string is palindrome*/
        String input = "abcba";
        boolean palindrome = isPalindrome(input);
        System.out.println(palindrome);
    }

    private static boolean isPalindrome(String input) {
        return IntStream
                .range(0, input.length() / 2) // 0
                .noneMatch(i-> input.charAt(i) != input.charAt(input.length() - i - 1));
    }
}
