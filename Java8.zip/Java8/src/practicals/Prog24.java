package practicals;

import java.lang.reflect.Array;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Prog24 {
    public static void main(String[] args) {
        /* find prime number from 1 to 10*/
        List<Integer> collect = IntStream
                .rangeClosed(2, 10)
                .filter(Prog24::isPrimeUsingStream)
                .boxed()
                .collect(Collectors.toList());

        System.out.println(collect);
    }

    private static boolean isPrimeUsingStream(int no) {
        int sqrt = (int) Math.sqrt(no);
        return IntStream
                .rangeClosed(2, sqrt)
                .noneMatch((i) -> no % i == 0);
    }

    private static boolean isPrime(int no) {
        int start = 2;
        while (start < no) {
            if(no % start == 0){
                return false;
            }
            start ++;
        }
        return true;
    }

}
