package practicals;

import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Practical2 {
    public static void main(String[] args) {
        /*Write a Java 8 program to concatenate two Streams?*/

        List<String> list1 = Arrays.asList("Java", "8");
        List<String> list2 = Arrays.asList("explained", "through", "programs");

        Stream.concat(Stream.of(list1), Stream.of(list2))
                .forEach(str -> System.out.print(str + " "));

        /* here combine two list into one using stream*/
        List<String> single = Stream.of(list1, list2)
                .flatMap(Collection::stream)
                .sorted(Comparator.reverseOrder())
                .collect(Collectors.toList());

        System.out.println(single);
    }

}
