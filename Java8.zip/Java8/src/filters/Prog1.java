package filters;

import model.Dish;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Prog1 {
    public static void main(String[] args) {
        List<Dish> dishes = new ArrayList<>();
        filterByDishes(dishes);

        List<Integer> integers = List.of(1, 4, 3, 5, 4, 2, 6);
        List<Integer> evenNumberWithDistnict = findEvenNumberWithDistnict(integers);


    }

    static List<String> filterByDishes(List<Dish> dishes){
        return dishes
                .stream()
                .filter(Dish::isVegetarian)
                .map(Dish::getName)
                .collect(Collectors.toList());
    }

    static List<Integer> findEvenNumberWithDistnict(List<Integer> integers){
        return integers
                .stream()
                .filter((i) -> i % 2 == 0)
                .distinct()
                .collect(Collectors.toList());
    }

}
