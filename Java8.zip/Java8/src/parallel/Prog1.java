package parallel;

import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Prog1 {
    public static void main(String[] args) {
        Integer integer = sequentialSum(10);
        System.out.println(integer);
    }

    /* using sequential stream*/
    private static Integer sequentialSum(int n){
        return Stream
                .iterate(1,(i)-> i + 1)
                .limit(n)
                .reduce(0, Integer::sum);
    }

    /* using parallel stream*/
    private static Integer parallelSum(int n){
        return Stream
                .iterate(1,(i)-> i + 1)
                .limit(n)
                .parallel()
                .reduce(0, Integer::sum);
    }

    /* using range method*/
    private static Integer parallelSumRange(int n) {
        return IntStream
                .rangeClosed(0, n)
                .parallel()
                .reduce(0, Integer::sum);
    }

}
