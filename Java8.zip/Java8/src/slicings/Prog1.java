package slicings;

import model.Dish;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Prog1 {
    public static void main(String[] args) {
        // this is sorted order dishes by calories
        List<Dish> specialMenu = Arrays.asList(
                new Dish("seasonal fruit", true, 120, Dish.Type.OTHER),
                new Dish("prawns", false, 300, Dish.Type.FISH),
                new Dish("rice", true, 350, Dish.Type.OTHER),
                new Dish("chicken", false, 400, Dish.Type.MEAT),
                new Dish("french fries", true, 530, Dish.Type.OTHER));

        /* comparing filter with takeWhile */
        /* by using filter will iterate with whole stream and check with each element
        * this may seem like huge benefit, but its can become useful if you work with potentially
        * large stream of elements using takeWhile */
        List<Dish> filterDishes = specialMenu
                .stream()
                .filter((dish) -> dish.getCalories() < 320)
                .collect(Collectors.toList());


        /* its work with potentially large number of data and
        * its will stop when predicate not match in sorting order */
        List<Dish> takeWhileDishes = specialMenu
                .stream()
                .takeWhile((dish) -> dish.getCalories() < 320)
                .collect(Collectors.toList());

        /* using dropWhile */
        /* to find data gretherthen 320*/
        /* the dropWhile oration is the complement of takeWhile */
        List<Dish> dropWhileDishes = specialMenu
                .stream()
                .dropWhile((dish -> dish.getCalories() < 320))
                .collect(Collectors.toList());

        /* truncating */
        List<String> dishes =
                specialMenu
                        .stream()
                        .filter(dish -> dish.getCalories() > 300)
                        .limit(3)
                        .map(Dish::getName)
                        .collect(Collectors.toList());

        /* skipping elements*/
        List<String> dishesSkip =
                specialMenu
                        .stream()
                        .filter((dish -> dish.getCalories() > 300))
                        .skip(2)
                        .map(Dish::getName)
                        .collect(Collectors.toList());

        /* filter the first two meat dishes*/
        List<String> meatDishes = specialMenu
                .stream()
                .filter((dish -> dish.getType() == Dish.Type.MEAT))
                .limit(2)
                .map(Dish::getName)
                .collect(Collectors.toList());

        /*find list of number of characters for each word*/
        List<Integer> noOfWord = specialMenu
                .stream()
                .map(Dish::getName)
                .map(String::length)
                .collect(Collectors.toList());



    }
}
