package java8collection;

import model.Dish;

import java.util.*;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.*;

public class Prog2 {
    public static void main(String[] args) {
        /* find no of dishes*/
        List<Dish> dishes = new ArrayList<>();
        long count = dishes.stream().count();

        /* find highest calories in dish*/
        Comparator<Dish> dishCaloriesComparator =
                Comparator.comparingInt(Dish::getCalories);

        /* summarization */
        IntSummaryStatistics collect = dishes
                .stream()
                .collect(summarizingInt(Dish::getCalories));

        /* find average*/
        double avg = dishes
                .stream()
                .collect(averagingDouble(Dish::getCalories));


        List<String> strings = List.of("1", "2", "3");
        String collect1 = strings
                .stream()
                .collect(joining(", "));
        System.out.println(collect1);

        /* find total calories*/
        dishes.add(new Dish("Anil", false, 100, Dish.Type.FISH));
        int totalCalories = dishes
                .stream()
                .map(Dish::getCalories)
                .reduce(0, Integer::sum);


    }
}
