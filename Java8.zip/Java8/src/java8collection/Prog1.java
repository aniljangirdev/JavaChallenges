package java8collection;

import model.Currency;
import model.Transaction;

import javax.xml.crypto.dsig.TransformService;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Prog1 {
    public static void main(String[] args) {
        /* find group a list of transcations by their currency*/
        List<Transaction> transactions = new ArrayList<>();
        Map<Currency, List<Transaction>> currencyTransactionMap =
                transactions
                .stream()
                .collect(Collectors.groupingBy(Transaction::getCurrency));

        System.out.println(currencyTransactionMap);

    }
}
