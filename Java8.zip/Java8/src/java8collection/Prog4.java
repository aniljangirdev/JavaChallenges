package java8collection;

import model.Dish;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

public class Prog4 {
    public static void main(String[] args) {
        Dish dishMomos = new Dish("Momo's", true, 100, Dish.Type.OTHER);
        Dish dishPasta  = new Dish("Pasta", true, 1001, Dish.Type.OTHER);
        Dish dishFish  = new Dish("FISH", true, 1003, Dish.Type.FISH);
        Dish dishMeat  = new Dish("Meat", true, 1002, Dish.Type.MEAT);

        List<Dish> dishes = List.of(dishMomos, dishPasta, dishFish, dishMeat);

        /* find ListOfDishNameGroupByDishType*/


        Map<Dish.Type, List<String>> listOfDishNameGroupByDishType =
                dishes
                        .stream()
                        .collect(Collectors.groupingBy(Dish::getType,
                                LinkedHashMap::new,
                                Collectors.mapping(Dish::getName, Collectors.toList())));


        System.out.println(listOfDishNameGroupByDishType);



    }
}
