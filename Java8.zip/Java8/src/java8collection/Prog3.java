package java8collection;

import model.Dish;

import java.util.*;
import java.util.function.BinaryOperator;
import java.util.function.Function;
import java.util.stream.Collectors;

import static java.util.Arrays.asList;
import static java.util.Comparator.comparing;
import static java.util.Comparator.comparingInt;
import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.maxBy;

public class Prog3 {
    public static void main(String[] args) {

        List<Dish> dishes = new ArrayList<>();
        int sum = dishes.stream()
                .mapToInt(Dish::getCalories)
                .sum();


        dishes
                .stream()
                .filter((dish) -> dish.getCalories() > 500)
                .collect(groupingBy(Dish::getCalories));

        Map<Dish.Type, List<Dish>> collect = dishes
                .stream()
                .collect(groupingBy(Dish::getType,
                        Collectors.filtering(dish -> dish.getCalories() < 500,
                                Collectors.toList())));


        Map<Dish.Type, List<Dish>> map = dishes
                .stream()
                .collect(groupingBy(Dish::getType,
                        Collectors.filtering(dish -> dish.getCalories() > 500, Collectors.toList())));


        /* find group by all TYPE WITH FILTER*/

        Map<Dish.Type, List<Boolean>> collect1 = dishes.stream()
                .collect(groupingBy(Dish::getType,
                        Collectors.mapping(dish -> dish.getCalories() > 500, Collectors.toList())));

        /* find group by all dishes name by dishType*/
        Map<Dish.Type, List<String>> map2 = dishes
                .stream()
                .collect(groupingBy(Dish::getType,
                        Collectors.mapping(Dish::getName, Collectors.toList())));

        /* */

        Map<String, List<String>> dishTags = new HashMap<>();
        dishTags.put("pork", asList("greasy", "salty"));
        dishTags.put("beef", asList("salty", "roasted"));
        dishTags.put("chicken", asList("fried", "crisp"));
        dishTags.put("french fries", asList("greasy", "fried"));
        dishTags.put("rice", asList("light", "natural"));
        dishTags.put("season fruit", asList("fresh", "natural"));
        dishTags.put("pizza", asList("tasty", "salty"));
        dishTags.put("prawns", asList("tasty", "roasted"));
        dishTags.put("salmon", asList("delicious", "fresh"));

        Map<Dish.Type, Set<String>> collect2 = dishes
                .stream()
                .collect(groupingBy(Dish::getType,
                        Collectors.flatMapping(dish -> dishTags.get(dish.getName()).stream(),
                                Collectors.toSet())
                ));

        System.out.println(collect2);

        dishes
                .stream()
                .collect(groupingBy(Dish::getType,
                        Collectors.counting()));

        Map<Dish.Type, Optional<Dish>> maxDish = dishes
                .stream()
                .collect(groupingBy(Dish::getType,
                        maxBy(comparingInt(Dish::getCalories))));

        Map<Dish.Type, Dish> mostCaloricByType =
                dishes.stream()
                        .collect(Collectors.toMap(Dish::getType,
                                Function.identity(),
                                BinaryOperator.maxBy(comparingInt(Dish::getCalories))));

        Map<Dish.Type, Integer> typeIntegerMap = dishes
                .stream()
                .collect(Collectors.groupingBy(Dish::getType,
                        Collectors.summingInt(Dish::getCalories)));





    }
}
