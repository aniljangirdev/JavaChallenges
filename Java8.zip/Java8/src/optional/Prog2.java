package optional;

import model.Car;
import model.Insurance;
import model.PPerson;
import model.Person;

import java.util.*;
import java.util.stream.Collectors;

public class Prog2 {
    public static void main(String[] args) {

        PPerson person = new PPerson();
        Car car = new Car();
        Insurance insurance = new Insurance();
        insurance.setName("XYZ");
        car.setInsurance(insurance);
        person.setCar(car);

        Optional<String> optional = Optional.empty();
        Optional<Car> car1 = Optional.of(car);
        Optional<Car> car2 = Optional.ofNullable(car);


        String s = Optional.of(insurance)
                .map(Insurance::getName)
                .orElse("N/A");

      /*  String insuranceName =
                Optional.of(person)
                        .map(PPerson::getCar)
                        .map(Car::getInsurance)
                        .map(Insurance::getName)
                        .orElse("N/A");*/

        Optional<PPerson> optionalPPerson = Optional.ofNullable(person);

        String carInsuranceName = getCarInsuranceName(optionalPPerson);

        List<PPerson> pPersonList = new ArrayList<>();
        pPersonList.add(person);

        Set<String> carInsuranceNameFromList = getCarInsuranceNameFromList(pPersonList);
        System.out.println(carInsuranceNameFromList);

        Insurance insurance1 = nullSafeFindCheapestInsurance(person, car).orElse(null);
        System.out.println(insurance1.getName());
    }

    private static String getCarInsuranceName(Optional<PPerson> person) {
        return person
                .flatMap(PPerson::getCar)
                .flatMap(Car::getInsurance)
                .map(Insurance::getName)
                .orElse("N/A");
    }

    private static String getPersonName(Optional<Person> pPerson) {
        return pPerson
                .map(Person::getLastName)
                .orElse("test");
    }

    private static Set<String> getCarInsuranceNameFromList(List<PPerson> pPersonList) {
        return pPersonList
                .stream() // convert list into stream API
                .map((PPerson::getCar)) // converted person into Stream<Optional<Car>>
                .map(car -> car.flatMap(Car::getInsurance)) // covert each Optional<Car> into Optional<Insurance>
                .map(insurance -> insurance.map(Insurance::getName)) // covert Optional<Insurance> into Optional<Name>
                .flatMap(Optional::stream) // convert into each stream Optional
                .collect(Collectors.toSet());
    }

    private static Optional<Insurance> nullSafeFindCheapestInsurance(PPerson pPerson, Car car) {
        Optional<PPerson> optionalPPerson = Optional.ofNullable(pPerson);
        Optional<Car> carOptional = Optional.ofNullable(car);
        return optionalPPerson
                .flatMap((p) -> carOptional.map((c -> findCheapestInsurance(p, c))));

    }

    public static Insurance findCheapestInsurance(PPerson person, Car car) {
        return person.getCar().get().getInsurance().get();
    }

    private static void isExist(Insurance insurance) {
        Optional.ofNullable(insurance)
                .filter((ins -> ins.getName().equals("Cambridge")))
                .ifPresent(System.out::println);
    }

    private static String getCarInsuranceName(PPerson pPerson, int minAge) {
        return Optional.ofNullable(pPerson)
                .filter(pPerson1 -> pPerson1.getAge() >= minAge)
                .flatMap(PPerson::getCar)
                .flatMap(Car::getInsurance)
                .map(Insurance::getName)
                .orElse("unKnown!");
    }

}
