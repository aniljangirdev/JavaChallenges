package optional;

import model.Car;
import model.Insurance;
import model.PPerson;

public class Prog1 {
    public static void main(String[] args) {
        PPerson person = new PPerson();
        /* getCarInsuranceName*/
        Car car = new Car();
        Insurance insurance =new  Insurance();
        insurance.setName("Anil");
        car.setInsurance(insurance);
        person.setCar(car);

//        String carInsuranceName = getCarInsuranceName(person);
//        System.out.println(carInsuranceName);

    }

//    private static String getCarInsuranceName(PPerson person) {
//        if (person != null && person.getCar() != null && person.getCar().getInsurance() != null) {
//            return person.getCar().getInsurance().getName();
//        }
//        return "UnKnown";
//    }
}


