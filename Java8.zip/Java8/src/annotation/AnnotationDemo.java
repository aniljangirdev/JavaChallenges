package annotation;

import exception.JsonSerializationException;
import model.Person;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

public class AnnotationDemo {
    public static void main(String[] args) throws Exception {
        Person person = new Person();
        person.setFirstName("anil");
        person.setLastName("jangir");
        person.setAge(30);
        String result = convertToJson(person);
        System.out.println(result);
    }

    private static void checkIfSerializable(Object o) {
        if (Objects.isNull(o)) {
            throw new JsonSerializationException("ths object to serialize is null");
        }
        Class<?> aClass = o.getClass();
        if (!aClass.isAnnotationPresent(JsonSerializable.class)) {
            throw new JsonSerializationException("The class " + aClass.getSimpleName()
                    + " is not annotated with JsonSerializable");
        }
    }

    private static void initializeObject(Object o) throws Exception {
        Class<?> aClass = o.getClass();
        for (Method declaredMethod : aClass.getDeclaredMethods()) {
            if (declaredMethod.isAnnotationPresent(Init.class)) {
                declaredMethod.setAccessible(true);
                declaredMethod.invoke(o);
            }
        }
    }

    private static String getJsonString(Object o) throws IllegalAccessException {
        Map<String, String> map = new LinkedHashMap<>();
        Class<?> aClass = o.getClass();
        for (Field declaredField : aClass.getDeclaredFields()) {
            declaredField.setAccessible(true);
            if (declaredField.isAnnotationPresent(JsonElement.class)) {
                map.put(declaredField.getName(), String.valueOf(declaredField.get(o)));
            }
        }
        return map
                .entrySet()
                .stream()
                .map((entry) -> entry.getKey() + ":" + entry.getValue())
                .collect(Collectors.joining(","));
    }

    private static String convertToJson(Object o) throws Exception {
        checkIfSerializable(o);
        initializeObject(o);
        return getJsonString(o);
    }

    private static String getKey(Field field) {
        String value = field.getAnnotation(JsonElement.class).key();
        return value.isEmpty() ? field.getName() : value;
    }

}

