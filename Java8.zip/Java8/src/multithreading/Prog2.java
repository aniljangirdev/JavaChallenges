package multithreading;

import annotation.JsonElement;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.*;
import java.util.stream.Collectors;

public class Prog2 {
    public static void main(String[] args) throws Exception {
        ExecutorService executorService = Executors.newCachedThreadPool();
        Future<String> future = executorService.submit(Prog2::callData);
//        Future<Integer> futureInt = executorService.submit(Prog2::value);
        String result = future.get(10, TimeUnit.SECONDS);
        System.out.println(result);

    }

    private static int value(){
        return 1;
    }


    private static String callData() throws IOException {
        URL url = new URL("https://api.publicapis.org/entries");
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("GET");
        try (InputStream inputStream = con.getInputStream();
             BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream))
        ) {
            return bufferedReader.lines()
                    .collect(Collectors.joining());
        }
    }
}
