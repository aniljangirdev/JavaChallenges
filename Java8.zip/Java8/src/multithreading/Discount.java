package multithreading;

import java.util.Arrays;

public class Discount {
    public enum Code {
        NONE(0), SILVER(1), GOLD(2), PLATINUM(3), DIAMOND(4);

        private final int percentage;

        Code(int percentage) {
            this.percentage = percentage;
        }

        public int getPercentage(String code) {
            return Arrays.stream(Code.values())
                    .filter((Code cc) -> cc.toString().equals(code))
                    .findFirst()
                    .map((c) -> c.percentage)
                    .orElse(-1);
        }
    }

    public static String applyDiscount(Quote quote) {
        return quote.getShopName() + " price is " +
                Discount.apply(quote.getPrice(), quote.getCode());
    }

    private static double apply(Double price, Code code) {
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        return (price * (100 - code.percentage) / 100);
    }

}
