package multithreading;

import java.util.List;
import java.util.Random;
import java.util.concurrent.*;
import java.util.stream.Collectors;

public class Prog3 {
    public static void main(String[] args) throws ExecutionException, InterruptedException {
//        Future<Double> sindoor = new Shop().getPriceAsync("Sindoor");
//        System.out.println(sindoor.get());
//        Shop shop = new Shop("new prodict");
//        long start = System.nanoTime();
//        Future<Double> priceAsync = shop.getPriceAsync("my favorite product!");
//        long invocationTime = (System.nanoTime() - start) / 1_000_000;
//        System.out.println("Invocation return after : " + invocationTime + "msecs");
//
//        try {
//            Double aDouble = priceAsync.get();
//            System.out.printf("price is %f%n", aDouble);
//        } catch (Exception exception) {
//            throw new RuntimeException(exception);
//        }
//        long retrievalTime = (System.nanoTime() - start) / 1_000_000;
//        System.out.println("Price returned after " + retrievalTime + " msecs");

        List<Shop> shops
                = List.of(new Shop("BestPrice1"),
                new Shop("BestPrice2"),
                new Shop("BestPrice3"),
                new Shop("BestPrice4"),
                new Shop("BestPrice5")
        );

        List<String> prices = findAllPrice1(shops);
        System.out.println(prices);

        long startTime = System.nanoTime();
        List<String> allPrice3 = findAllPrice4(shops);
        System.out.println(allPrice3);
        long totalTime = (System.nanoTime() - startTime) / 1_000_000;
        System.out.println("total time : " + totalTime);
    }


    private static Executor getExecutor(List<Shop> shops) {
        return Executors.newFixedThreadPool(Math.min(shops.size(), 100),
                (r -> {
                    Thread thread = new Thread(r);
                    thread.setDaemon(true);
                    return thread;
                }));
    }

    private static List<String> findAllPrice1(List<Shop> shops) {
        return shops
//                .parallelStream()
                .stream()
                .map((shop) -> CompletableFuture.supplyAsync(() -> String.format("%s price is %.2f",
                                shop.getName(), shop.calculatePrice(shop.getName())),
                        getExecutor(shops)))
//                .map((shop -> String.format("%s price is %.2f",
//                        shop.getName(), shop.calculatePrice(shop.getName()))))
                .collect(Collectors.toList())
                .stream()
                .map((CompletableFuture::join))
                .collect(Collectors.toList());
    }

    private static List<String> findAllPrice2(List<Shop> shops) {
        List<CompletableFuture<String>> priceFeature = shops
                .stream()
                .map((shop -> CompletableFuture.supplyAsync(() -> String.format("%s price is %.2f",
                        shop.getName(), shop.calculatePrice(shop.getName())))))
                .collect(Collectors.toList());

        return priceFeature
                .stream()
                .map(CompletableFuture::join)
                .collect(Collectors.toList());

    }

    private static List<String> findAllPrice3(List<Shop> shops) {
        return shops
                .stream()
                .map((shop -> shop.getPrice1(shop.getName())))
                .map((Quote::parse))
                .map(Discount::applyDiscount)
                .collect(Collectors.toList());
    }

    private static List<String> findAllPrice4(List<Shop> shops) {
        List<CompletableFuture<String>> priceFutures = shops
                .stream()
                .map((shop -> CompletableFuture.supplyAsync(() -> shop.getPrice1(shop.getName()), getExecutor(shops))))
                .map((future) -> future.thenApply(Quote::parse))
                .map((future) -> future.thenCompose(quote -> CompletableFuture.supplyAsync(() -> Discount.applyDiscount(quote),
                        getExecutor(shops))))
                .collect(Collectors.toList());
        return priceFutures
                .stream()
                .map(CompletableFuture::join)
                .collect(Collectors.toList());
    }

    private static List<String> findPrices(List<Shop> product) {
        return product.parallelStream()
                .map((shop -> {
                    try {
                        return String.format("%s price is %.2f",
                                shop.getName(), shop.getPriceAsync(shop.getName()).get());
                    } catch (InterruptedException | ExecutionException e) {
                        throw new RuntimeException(e);
                    }
                }))
                .collect(Collectors.toList());
    }


}

class Shop {
    private String name;
    private static final Random random = new Random();

    public Shop(String s) {
        this.name = s;
    }

    public String getName() {
        return name;
    }

    public Future<Double> getPriceAsync(String product) {
        return CompletableFuture
                .supplyAsync(() -> calculatePrice(product));
    }

    void delay() {
        try {
            Thread.sleep(1000L);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    double calculatePrice(String product) {
        delay();
        return random.nextDouble() * product.charAt(0) + product.charAt(1);
    }

    String getPrice1(String product) {
        Double price = calculatePrice(product);
        Discount.Code code = Discount.Code.values()[random.nextInt(Discount.Code.values().length)];
        return String.format("%s:%.2f:%s", code.name(), price, code);
    }


}
