package multithreading;

import java.util.concurrent.Flow;

public class Prog6 {
    public static void main(String[] args) {

    }
}
