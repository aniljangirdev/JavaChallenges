package multithreading;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

public class Prog5 {
    public static void main(String[] args) throws ExecutionException, InterruptedException {
        Product product = new Product();
        product.setDiscount(5);
        product.setPrice(100);
        Double aDouble = finalPriceAfterDiscount(product);
        System.out.println(aDouble);
    }

    private static Double finalPriceAfterDiscount(Product product) throws ExecutionException, InterruptedException {
        CompletableFuture<Double> doubleCompletableFuture = CompletableFuture.supplyAsync(product::getPrice)
                .thenCompose((price) -> CompletableFuture.supplyAsync(product::getDiscount));
        return doubleCompletableFuture.get();
    }

    private static int findPrice() throws InterruptedException {
        Thread.sleep(1000);
        return 100;
    }

    private static double findDiscount() throws InterruptedException {
        Thread.sleep(1000);
        return 5.0;
    }
}

class Product{
    private String name;
    private int price;
    private double discount;

    public void setName(String name) {
        this.name = name;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }

    public String getName() {
        return name;
    }

    public double getDiscount() {
        return discount;
    }

    public int getPrice() {
        return price;
    }
}
