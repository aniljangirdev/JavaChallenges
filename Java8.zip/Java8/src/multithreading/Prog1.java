package multithreading;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.function.IntConsumer;

public class Prog1 {
    public static void main(String[] args) throws InterruptedException {
        int x = 1337;
        Result result = new Result();
        Thread t1 = new Thread(()-> result.setLeft(x));
        Thread t2 = new Thread(()-> result.setRight(x));

        t1.start();
        t2.start();
        t1.join();
        t2.join();

        ExecutorService executorService = Executors.newFixedThreadPool(2);
        Future<?> future1 = executorService.submit(() -> result.setLeft(x));
        Future<?> future2 = executorService.submit(() -> result.setRight(x));

        executorService.shutdown();

        f(x, (int y   )->{
            result.setLeft(y);
            System.out.println("x" + result.getLeft());
        });
    }


    static void f(int x, IntConsumer dealWithResult) {

    }

}

class Result{
    private int left;
    private int right;

    public int getLeft() {
        return left;
    }

    public int getRight() {
        return right;
    }

    public void setLeft(int left) {
        this.left = left;
    }

    public void setRight(int right) {
        this.right = right;
    }
}

