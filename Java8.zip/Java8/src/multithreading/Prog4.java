package multithreading;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class Prog4 {
    public static void main(String[] args) {

    }
}
