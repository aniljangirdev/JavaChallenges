package datetime;

import java.time.*;
import java.time.chrono.HijrahDate;
import java.time.chrono.JapaneseDate;
import java.time.chrono.MinguoDate;
import java.time.chrono.ThaiBuddhistDate;
import java.time.format.DateTimeFormatter;
import java.time.zone.ZoneRules;
import java.util.Locale;
import java.util.TimeZone;

public class Prog3 {
    public static void main(String[] args) {
        LocalDate localDate = LocalDate.now();
        String date1 = localDate.format(DateTimeFormatter.BASIC_ISO_DATE);
        String date2 = localDate.format(DateTimeFormatter.ISO_LOCAL_DATE);

        System.out.println("date1 " + date1 + " date2 " + date2);

        LocalDate parse = LocalDate.parse("2022-04-08", DateTimeFormatter.ISO_LOCAL_DATE);

        System.out.println(parse);

        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("d. MMMM yyyy")
                .withLocale(Locale.ITALIAN);
        String format = localDate.format(dateTimeFormatter);
        System.out.println(format);


        ZoneId zoneId = ZoneId.of("Europe/Rome");
        ZonedDateTime zonedDateTime = LocalDate.now().atStartOfDay(zoneId);

        Instant.now().atZone(zoneId);

        LocalDateTime localDateTime = LocalDateTime.ofInstant(Instant.now(), zoneId);

        ZoneId zoneId1 = TimeZone.getTimeZone(zoneId).toZoneId();

        JapaneseDate from = JapaneseDate.from(localDateTime);


    }
}
