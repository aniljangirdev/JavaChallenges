package datetime;

import java.time.*;
import java.time.temporal.*;

public class Prog2 {
    public static void main(String[] args) {
        LocalDate date1 = LocalDate.of(2017, Month.SEPTEMBER, 21);
        LocalDate date2 = date1.withYear(2011);
        LocalDate date3 = date2.withDayOfMonth(25);
        LocalDate date4 = date3.with(ChronoField.MONTH_OF_YEAR, 2);
        System.out.println(date4);

        LocalDate date5 = date4.plusDays(1); // 2011-03-02

        System.out.println(date5);

        LocalDate now = LocalDate.now();
        System.out.println("date now " + now);

        LocalDateTime localDateTime = LocalDateTime.now();
        System.out.println("time now " + localDateTime);

        TemporalAdjuster temporalAdjuster = (Temporal t) -> {
            DayOfWeek dayOfWeek = DayOfWeek.of(t.get(ChronoField.DAY_OF_WEEK));
            int dayToAdd = 1;
            if (dayOfWeek == DayOfWeek.FRIDAY) {
                dayToAdd = 3;
            } else if (dayOfWeek == DayOfWeek.SATURDAY) {
                dayToAdd = 2;
            }
            return t.plus(dayToAdd, ChronoUnit.DAYS);
        };

        LocalDate nextWorkingDay = now.with(temporalAdjuster);
        System.out.println("next working days " + nextWorkingDay);

    }
}
