package datetime;

import java.time.*;
import java.util.Calendar;
import java.util.Date;

public class Prog1 {
    public static void main(String[] args) {
        Date date = new Date(117, Calendar.SEPTEMBER, 21);
        System.out.println(date.toString());

        LocalDate localDate = LocalDate.of(2021, Month.SEPTEMBER, 21);
        int year = localDate.getYear();
        Month month = localDate.getMonth();
        int dayOfMonth = localDate.getDayOfMonth();
        DayOfWeek dayOfWeek = localDate.getDayOfWeek();
        int i = localDate.lengthOfMonth();
        boolean leapYear = localDate.isLeapYear();
        LocalDate.now();
        System.out.println();

//        LocalTime localTime = LocalTime.of(12, 45, 20);
        LocalTime localTime = LocalTime.parse("12:45:20");
        int hour = localTime.getHour();
        int minute = localTime.getMinute();
        int second = localTime.getSecond();
        System.out.println();

        LocalDateTime localDateTime = LocalDateTime.of(2021, Month.SEPTEMBER, 21, 12, 45, 20);
        LocalTime localTime1 = localDateTime.toLocalTime();
        LocalTime localTime2 = localDateTime.toLocalTime();


        Instant instant = Instant.ofEpochSecond(1);

        // duration only work with localtime, not with localDate and instant
        Duration.between(localTime1, localTime2);

        Period period = Period
                .between(localDate, localDate);

        Duration duration = Duration.ofMinutes(3);
        long seconds = duration.getSeconds();
        System.out.println();

        Period.ofWeeks(3);
        Period of = Period.of(2, 6, 1);
        System.out.println();

    }
}
