package datetime;

import custominterface.TriFunction;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Iterator;
import java.util.function.BiFunction;
import java.util.function.Function;

public class Prog4 {
    public static void main(String[] args) {
        LocalDate localDate = LocalDate.now();
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy MM dd");
        DateTimeFormatter dateTimeFormatterExpected = DateTimeFormatter.ofPattern("dd MM yyyy");
        String text = localDate.format(dateTimeFormatter);
        LocalDate output = LocalDate.parse(text, dateTimeFormatter);
        System.out.println(output);

        /* Function */
        Function<String, Integer> function = Integer::parseInt;
        BiFunction<String, String, String> concat = String::concat;
        BiFunction<Integer, String, String> substr = (idx, s2) -> s2.substring(idx);
        BiFunction<Integer, Integer , Integer> sumFunction = Integer::sum;
        TriFunction<String, Integer, Integer, String> stringIntegerIntegerStringTriFunction = String::substring;


        Function<Integer, Integer> multiply = (i) -> i * 2;
        Function<Integer, Integer> add = (i) -> i + 3;

        Function<Integer, Integer> compose = multiply.compose((Integer t) -> t + 3);
        Integer apply = compose.apply(10);
        System.out.println(apply);

    }
}
