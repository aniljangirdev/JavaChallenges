package model;

public interface IntPredicate<T> {
    boolean test(int i);
}
