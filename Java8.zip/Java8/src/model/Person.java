package model;

import annotation.Init;
import annotation.JsonElement;
import annotation.JsonSerializable;

@JsonSerializable
public class Person {

    @JsonElement
    private String firstName;

    @JsonElement
    private String lastName;

    @JsonElement(key = "personAge")
    private Integer age;

    @Init
    private void initNames() {
        setFirstName(this.firstName.substring(0, 1).toUpperCase() + this.firstName.substring(1));
        setLastName(this.lastName.substring(0, 1).toUpperCase() + this.lastName.substring(1));
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public Integer getAge() {
        return age;
    }
}
