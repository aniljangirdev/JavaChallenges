package model;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Prog28 {
    public static void main(String[] args) {
        List<Dish> dishes = List.of(new Dish("test", true, 10, Dish.Type.FISH));
        Map<CaloricLevel, List<Dish>> caloricLevelListMap =
                dishes
                .stream()
                .collect(Collectors.groupingBy(Prog28::getCaloricLevel));

        List<Inventory> inventories = new ArrayList<>();
        inventories.sort(Comparator.comparing(Inventory::getName));

        int totalCalories = dishes
                .stream()
                .mapToInt(Dish::getCalories)
                .sum();

    }

    private static CaloricLevel getCaloricLevel(Dish dish){
        if(dish.getCalories() >  10) return CaloricLevel.DIET;
        else if( dish.getCalories() > 50) return CaloricLevel.FAT;
        else return CaloricLevel.NORMAL;
    }


}
