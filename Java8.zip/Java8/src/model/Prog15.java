package model;

import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class Prog15 {
    public static void main(String[] args) {
        // print all prime numbers
        boolean prime = isPrime(2);

        IntStream
                .rangeClosed(2, 11)
                .filter(Prog15::isPrimeStream)
                .boxed()
                .collect(Collectors.toList())
                .forEach(System.out::println);


    }

    /* find prime using stream API*/
    private static boolean isPrimeStream(int num){
        int numRoot =(int) Math.sqrt(num);
        return IntStream.rangeClosed(2, numRoot)
                .noneMatch(i -> num % i == 0);
    }

    private static boolean isPrime(int num){
        int start = 2;
        while (start < num) {
            if(num % start == 0)
                return false;
            start += 1;
        }
        return true;
    }
}
