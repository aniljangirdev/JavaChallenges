package model;

import java.util.List;
import java.util.Optional;

public class PPerson {
    private int age;
    private Optional<Car> car;

    public Optional<Car> getCar() {
        return car;
    }

    public int getAge() {
        return age;
    }

    public void setCar(Car car) {
        this.car = Optional.ofNullable(car);
    }

    public List<String> hobbies;

    public List<String> getHobbies() {
        return hobbies;
    }
}