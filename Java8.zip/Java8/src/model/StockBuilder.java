package model;

import java.math.BigDecimal;

public class StockBuilder {
    private final MethodChainingOrderBuilder methodChainingOrderBuilder;
    private final Trade trade;
    private final Stock stock = new Stock();

    public StockBuilder(MethodChainingOrderBuilder methodChainingOrderBuilder, Trade trade, String symbol) {
        this.methodChainingOrderBuilder = methodChainingOrderBuilder;
        this.trade = trade;
        this.stock.setSymbol(symbol);
    }

    public TradeBuilderWithStock on(String market) {
        stock.setMarket(market);
        trade.setStock(stock);
        return new TradeBuilderWithStock(methodChainingOrderBuilder, trade);
    }

}
