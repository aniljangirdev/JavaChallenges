package model;

import java.util.function.BiFunction;
import java.util.function.Function;

public class Prog9 {
    public static void main(String[] args) {
    }

    public interface ADDER{
        int add(int a, int b);
    }

    interface SMART_ADDER extends ADDER{
        int add(double a, double b);
    }
}




