package model;

public class Customer {
    @Override
    public String toString() {
        return "Test customer";
    }
}
