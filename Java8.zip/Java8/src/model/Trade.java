package model;

import java.math.BigDecimal;

public class Trade {
    public enum Type {BUY, SELL}

    private Type type;
    private BigDecimal price;
    private Integer quantity;
    private Stock stock;

    public BigDecimal getPrice() {
        return price;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public Stock getStock() {
        return stock;
    }

    public Type getType() {
        return type;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public void setStock(Stock stock) {
        this.stock = stock;
    }

    public void setType(Type type) {
        this.type = type;
    }

    public Double getValue() {
        return this.price.doubleValue() * quantity;
    }

    @Override
    public String toString() {
        return "Trade{" +
                "type=" + type +
                ", price=" + price +
                ", quantity=" + quantity +
                ", stock=" + stock +
                '}';
    }
}
