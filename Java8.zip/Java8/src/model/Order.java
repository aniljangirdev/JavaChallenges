package model;

import java.util.ArrayList;
import java.util.List;

public class Order {
    private String customer;
    private List<Trade> list = new ArrayList<>();

    public void setCustomer(String customer) {
        this.customer = customer;
    }

    public void setList(List<Trade> list) {
        this.list = list;
    }

    public List<Trade> getList() {
        return list;
    }

    public String getCustomer() {
        return customer;
    }

    public Double getValue(){
        return list
                .stream()
                .mapToDouble(Trade::getValue)
                .sum();
    }

    @Override
    public String toString() {
        return "Order{" +
                "customer='" + customer + '\'' +
                ", list=" + list +
                '}';
    }
}
