package model;

import java.math.BigDecimal;

public class TradeBuilderWithStock {
    private final MethodChainingOrderBuilder orderBuilder;
    private final Trade trade;

    TradeBuilderWithStock(MethodChainingOrderBuilder orderBuilder, Trade trade) {
        this.orderBuilder = orderBuilder;
        this.trade = trade;
    }

    public MethodChainingOrderBuilder at(double price) {
        trade.setPrice(new BigDecimal(price));
        return orderBuilder.addTrade(trade);
    }
}