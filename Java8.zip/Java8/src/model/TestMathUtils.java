package model;

public class TestMathUtils {

    public static int additionBy1(Integer no){
        return no + 1;
    }
}
