package model;

public enum CaloricLevel {
    DIET, NORMAL, FAT
}
