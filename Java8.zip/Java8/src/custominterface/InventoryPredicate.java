package custominterface;

import model.Inventory;

public interface InventoryPredicate<T> {
    boolean test(T t);
}
