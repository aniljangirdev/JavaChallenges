package custominterface;

import java.io.BufferedReader;

@FunctionalInterface
public interface BufferReaderProcessor {
    String process(BufferedReader bufferedReader);
}
