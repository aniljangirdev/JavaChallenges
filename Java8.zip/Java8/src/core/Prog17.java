package core;

import java.util.function.IntBinaryOperator;
import java.util.function.ToIntBiFunction;

public class Prog17 {
    public static void main(String[] args) {
        /*
         Predicate  T -> R
        *       IntPredicate, LongPredicate, DoublePredicate
        *  Consumer   T -> void
        *       IntConsumer, LongConsumer, DoubleConsumer
        *  Function   T -> R
        *       IntFunction, IntToDoubleFunction, IntToLong,
        *  Supplier   () -> R
        *       Boolean, Integer, Long, Double
        *  UnaryOperator T -> T
        *       IntUnary, LongUnary, DoubleUnary
        *  BinaryOperator (T, T) -> T
        *       IntBinary, DoubleBinary, LongBinary
        *  BiPredicate (T, U) -> boolean
        *  BiConsumer  (T, U) -> void
        *  BiFunction (T, U) -> R
        *
        * */

        ToIntBiFunction<Integer, Integer> function = (no1, no2) -> no1 * no2;
        int i = function.applyAsInt(10, 20);
        System.out.println(i);

        IntBinaryOperator intBinaryOperator = (no1, no2) -> no1 * no2;
        int b = intBinaryOperator.applyAsInt(1, 2);
        System.out.println(b);


    }
}
