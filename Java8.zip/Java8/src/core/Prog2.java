package core;

import model.Inventory;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class Prog2 {
    public static void main(String[] args) {
        List<Inventory> inventories = new ArrayList<>();
        List<Inventory> sortedByName = inventories.stream()
                .parallel()
                .sorted(Comparator.comparing(Inventory::getName))
                .collect(Collectors.toList());

    }
}
