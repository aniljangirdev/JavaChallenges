package core;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.function.Function;

public class Prog14 {
    public static void main(String[] args) {
        List<String> strings = List.of("Lambda","in","action!");

        List<Integer> map = map(strings, Integer::valueOf);
        System.out.println("MAP : "+ map);

        List<Integer> integers = List.of(1, 2, 3, 4);
        Function<Integer, String> integerStringFunction = String::valueOf;
        List<String> map1 = map(integers, integerStringFunction);
        System.out.println("MAP in string : "+ map1);

        /* boxing vs autoboxing
        * boxing: converting from Primitive to Generic type
        * auto boxing: converting from Generic type tp Primitive type
        * */


    }

    /* generic class using Function interface*/
    private static <T, R> List<R> map(Collection<T> c, Function<T,R> f){
        List<R> result = new ArrayList<>();
        for (T t : c) {
            result.add(f.apply(t));
        }
        return result;
    }

}
