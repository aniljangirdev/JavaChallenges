package core;

import model.Inventory;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Prog22 {
    public static void main(String[] args) {
        Comparator<Inventory> inventoryComparator
                = Comparator.comparing(Inventory::getName);
        List<Inventory> inventories = new ArrayList<>();
        inventories.sort(inventoryComparator);

        /* comparing with reverse order*/
        inventories.sort(Comparator.comparing(Inventory::getName).reversed());

        // comparing with find two inventory that same COLOR
        inventories.sort(Comparator.comparing(Inventory::getName).reversed()
                .thenComparing(Inventory::getColor));
    }
}
