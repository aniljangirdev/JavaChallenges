package core;

import java.util.Collection;
import java.util.List;
import java.util.function.Consumer;

public class Prog13 {
    public static void main(String[] args) {
        /* example of Consumer interface*/
        /* eg. foreach..*/

        /*make custom forEach generic method*/
        List<String> strings = List.of("Test1", "Test2");
        forEach(strings);

        // with string list
        forEachWithConsumer(strings, System.out::println);

        // with integer List
        forEachWithConsumer(List.of(1,2,3,4,5), (Integer i)-> System.out.println());
    }

    /* here simple create genric class*/
    private static <T> void forEach(Collection<T> list){
        for (T t : list) {
            System.out.println(t);
        }
    }

    /* here create generic class with Consumer*/
    private static <T> void forEachWithConsumer(Collection<T> list, Consumer<T> c){
        for (T t : list) {
            c.accept(t);
        }
    }
}
