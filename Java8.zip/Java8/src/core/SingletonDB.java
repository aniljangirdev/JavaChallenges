package core;

import model.Customer;

public class SingletonDB {

    private static SingletonDB instance;

    public static SingletonDB getInstance() {
        if (instance == null) {
            instance = new SingletonDB();
        }
        return instance;
    }

    public Customer getCustomer(int id){
        return new Customer();
    }

}