package core;

public class prog32 implements BBB,CCC {
    public static void main(String[] args) {
        /* diamond problem*/

    }

    @Override
    public void hello() {
        BBB.super.hello();
    }
}

interface AAA{
    default void hello() {
        System.out.println("Hello from AAA");
    }
}
interface BBB extends AAA{
    default void hello() {
        System.out.println("Hello from BBB");
    }
}

interface CCC extends AAA {
    void hello();
}

