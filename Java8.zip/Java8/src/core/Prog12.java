package core;

import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class Prog12 {
    public static void main(String[] args) {

        /*example of predicate interface*/
        List<String> strings = List.of("test1", "test2", "");
        List<String> notEmptyStringList = filter(strings, (str) -> !str.isEmpty());
        System.out.println("output : " + notEmptyStringList);
    }

    // here make genric filter that work for all type
    private static <T> List<T> filter(List<T> t, Predicate<T> p) {
        return t.stream()
                .filter(p)
                .collect(Collectors.toList());
    }
}
