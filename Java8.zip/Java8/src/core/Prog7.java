package core;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class Prog7 {
    public static void main(String[] args) {

        // using annonious class
        ExecutorService executorService = Executors.newCachedThreadPool();
        Future<String> stringFuture = executorService.submit(new Callable<String>() {
            @Override
            public String call() throws Exception {
                return Thread.currentThread().getName();
            }
        });

        // using lambda
        Future<String> stringFut = executorService.submit(() -> Thread.currentThread().getName());
    }
}
