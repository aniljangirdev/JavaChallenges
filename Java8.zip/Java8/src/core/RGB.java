package core;

public class RGB {
    int r;
    int g;
    int b;

    public RGB(int r, int g, int b) {
        this.r = r;
        this.g = g;
        this.b = b;
    }
}
