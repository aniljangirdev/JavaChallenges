package core;

public class Prog31 implements AA,BB {
    public static void main(String[] args) {
        new Prog31().getNumber();
    }

    @Override
    public Integer getNumber() {
        return BB.super.getNumber();
    }
}
interface AA{
    default Number getNumber() {
        return 10;
    }

}

interface BB {
    default Integer getNumber() {
        return 42;
    }
}
