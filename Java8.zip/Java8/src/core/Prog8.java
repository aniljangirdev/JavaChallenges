package core;

import model.Inventory;

import java.nio.file.DirectoryStream;
import java.util.List;
import java.util.function.*;

public class Prog8 {
    public static void main(String[] args) {

        Function<String, Integer> stringPredicate = String::length;

        Predicate<String> predicate = String::isBlank;

        // take one parameter as string and return Integer using Lambda Way
        Function<String, Integer> stringIntegerFunction = (String s) -> s.length();

        // take two parameter and return one integer
        BiFunction<Integer, Integer, Integer> function11 = (Integer x, Integer y) -> x + y;

        Function<List<String>, Boolean> listFilter = (List<String> list) -> list.isEmpty();

        Supplier<Inventory> runnable = () -> new Inventory();

        Consumer<Inventory> inventoryConsumer = (Inventory inventory) -> {
            System.out.println(inventory.getColor());
        };


    }
}
