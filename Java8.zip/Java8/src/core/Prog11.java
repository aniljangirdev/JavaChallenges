package core;

import custominterface.BufferReaderProcessor;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.stream.Collectors;

public class Prog11 {
    public static void main(String[] args) throws IOException {
        String result = processFile((BufferedReader br) -> br.lines().collect(Collectors.joining("\n")));
        System.out.println("result : "+ result);
    }

    private static String processFile(BufferReaderProcessor bufferReaderProcessor) throws IOException {
        try (BufferedReader bufferedReader = new BufferedReader(new FileReader("./temp/test.txt"))) {
            return bufferReaderProcessor.process(bufferedReader);
        }
    }
}
