package core;

import model.Dish;
import model.Employee;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Prog26 {
    public static void main(String[] args) {

        List<Employee> employees = List.of(new Employee());

        employees.sort(Comparator.comparing(Employee::getId).thenComparing(Employee::getName));

    }

    static void findByMultiGroup() {
        List<Dish> dishes = List.of();
        Map<Boolean, Map<Integer, List<Dish>>> map = dishes.stream()
                .collect(Collectors.groupingBy(Dish::isVegetarian, Collectors.groupingBy(Dish::getCalories)));

        Comparator<Dish> dishComparator = Comparator.comparing(Dish::isVegetarian)
                .thenComparing(Dish::getCalories);

    }

    static List<String> findAllErrorsWithStream() throws IOException {
        String filename = "test";
        Path of = Path.of(filename);
        try (Stream<String> lines = Files.lines(of)) {
            return lines.filter((line) -> line.startsWith("ERROR")).limit(40).collect(Collectors.toList());
        }
    }

    static List<String> findAllErrors() throws IOException {
        List<String> errors = new ArrayList<>();
        int count = 0;
        String fileName = ".test";
        try (BufferedReader bufferedReader = new BufferedReader(new FileReader(fileName))) {
            String line = bufferedReader.readLine();
            while (line != null && count < 40) {
                if (line.startsWith("ERROR")) {
                    errors.add(line);
                    count++;
                }
                line = bufferedReader.readLine();
            }
        }
        return errors;
    }

}
