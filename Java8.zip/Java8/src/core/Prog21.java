package core;

import custominterface.TriFunction;
import model.Inventory;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

public class Prog21 {
    public static void main(String[] args) {
        Map<String, Function<Integer, Inventory>> map = new HashMap<>();
        map.put("apple", Inventory::new);
        map.put("banana", Inventory::new);

        Inventory apple = map.get("apple").apply(1);

        // constructor with three argument
        TriFunction<Integer, Integer, Integer, RGB> colorFactory = RGB::new;
        RGB rgbColor = colorFactory.apply(1, 2, 4);
    }

}
