package core;

public class Prog29 {
    public static void main(String[] args) {
        Prog29 prog29 = new Prog29();
//        Integer i = 10;
        int i = 10;

        prog29.print(i);

    }

    void print(int no) {
        System.out.println( "int "+no);
    }
    void print(String no) {
        System.out.println("string "+ no);
    }
    void print(Object no) {
        System.out.println("object "+ no);
    }


}
