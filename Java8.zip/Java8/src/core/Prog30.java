package core;

public class Prog30 implements A,B {
    public static void main(String[] args) {
        Prog30 prog30 = new Prog30();
        prog30.hello();
    }

    @Override
    public void hello() {
        A.super.hello();
    }
}

interface A {
    default void hello() {
        System.out.println("Hello from A");
    }
}

interface B {
    default void hello() {
        System.out.println("Hello from B");
    }
}

 class D implements A {
     public void hello() {
         System.out.println("Hello from D");
     }
}

