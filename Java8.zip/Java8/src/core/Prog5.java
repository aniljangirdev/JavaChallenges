package core;

import custominterface.InventoryPredicate;
import model.Inventory;
import model.Transaction;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Prog5 {
    public static void main(String[] args) {

        List<Inventory> inventories = new ArrayList<>();
        filterByApple(inventories, new InventoryWithColorGreenPredicate());
        filterByApple(inventories, new InventoryWithAppleName());

        // here used anonymous class, that does not have Name
        filterByApple(inventories, new InventoryPredicate<Inventory>() {
            @Override
            public boolean test(Inventory i) {
                return i.getColor() == Inventory.COLOR.GREEN;
            }
        });

        // here used lambda style using generic way
        filterByApple(inventories, i -> i.getColor() == Inventory.COLOR.GREEN);

        // remove unwanted casting from lambda expression
        filterByApple(inventories, i -> i.getColor() == Inventory.COLOR.GREEN);

        // filter with transaction using generic
        List<Transaction> transactions = new ArrayList<>();
        filterByApple(transactions, t -> t.getPrice() > 5000);


    }

    // here create generic method that work for all models
    static <T> List<T> filterByApple(List<T> models, InventoryPredicate<T> predicate) {
        return models
                .stream()
                .filter(predicate::test)
                .collect(Collectors.toList());
    }

    // strategy pattern by interface 1
    static class InventoryWithColorGreenPredicate implements InventoryPredicate<Inventory> {
        @Override
        public boolean test(Inventory inventory) {
            return inventory.getColor() == Inventory.COLOR.GREEN;
        }
    }

    // strategy pattern by interface 2
    static class InventoryWithAppleName implements InventoryPredicate<Inventory> {

        @Override
        public boolean test(Inventory inventory) {
            return inventory.getName().equals("Apple");
        }
    }

}
