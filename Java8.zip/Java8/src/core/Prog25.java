package core;

import java.util.function.Function;

public class Prog25 {
    public static void main(String[] args) {
        /* LETTER using andThen*/
        String body = "Hello, labda";
        Function<String, String> functionHeader = Prog25::addHeader;
        Function<String, String> functionResult =
                functionHeader.andThen(Prog25::checkSpelling)
                        .andThen(Prog25::addFooter);

        String result = functionResult.apply(body);
        System.out.println(result);
    }

    static String addHeader(String text){
        return "Header " + text;
    }

    static String addFooter(String text){
        return text + " Footer";
    }

    static String checkSpelling(String text) {
        return text.replaceAll("labda", "Lambda");
    }

}
