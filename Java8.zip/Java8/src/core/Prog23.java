package core;

import model.Inventory;

import java.util.function.Predicate;

public class Prog23 {
    public static void main(String[] args) {
        // predicate with green Inventory
        Predicate<Inventory> greenInventory =
                (Inventory i) -> i.getColor() == Inventory.COLOR.GREEN;

        // except green inventory with negate method
        Predicate<Inventory> inventoryPredicate = greenInventory.negate();

        /* with predicate and() method */
        Predicate<Inventory> inventoryPredicateAnd = greenInventory.negate()
                .and((i) -> i.getId() == 1);

        /*  (a && b) || c */
        Predicate<Inventory> havyInvetoryForSpecialUSer =
                greenInventory.and(i -> i.getId() == 1)
                        .or((i) -> i.getName().equals("FRESH"));
    }
}
