package core;

import model.*;

import java.math.BigDecimal;
import java.util.List;

import static model.MethodChainingOrderBuilder.forCustomer;

public class Prog27 {
    public static void main(String[] args) {
        Order order = new Order();
        order.setCustomer("Anil");

        Trade trade1 = new Trade();
        trade1.setType(Trade.Type.BUY);
        trade1.setPrice(new BigDecimal(1000));
        trade1.setQuantity(10);

        Stock stock = new Stock();
        stock.setMarket("NYSE");
        stock.setSymbol("IBM");
        trade1.setStock(stock);


        Trade trade2 = new Trade();
        trade2.setType(Trade.Type.BUY);
        trade2.setPrice(new BigDecimal(2000));
        trade2.setQuantity(15);

        Stock stock2 = new Stock();
        stock2.setMarket("NASYE");
        stock2.setSymbol("GOOGL");
        trade2.setStock(stock2);

        List<Trade> trades = List.of(trade1, trade2);
        order.setList(trades);

        Order order1 = forCustomer("Anil")
                .buy(80)
                .stock("Google")
                .on("YMCSA")
                .at(1000)
                .sell(100)
                .stock("facebook")
                .on("FB")
                .at(200)
                .end();

        System.out.println(order1);
    }
}
