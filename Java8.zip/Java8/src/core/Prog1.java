package core;

import model.Inventory;

import java.io.File;
import java.io.FileFilter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class Prog1 {
    public static void main(String[] args) {

        //old way of filtering hidden file
        File[] hiddenFiles = new File(".").listFiles(new FileFilter() {
            @Override
            public boolean accept(File file) {
                return file.isHidden();
            }
        });

        // using java 8 style
        File[] files = new File(".").listFiles(File::isHidden);

        // filter all Green APPle
        List<Inventory> inventories = new ArrayList<>();
        Inventory inventory = new Inventory();
        inventory.setId(1);
        inventory.setName("APPLE1");
        inventory.setColor(Inventory.COLOR.RED);

        Inventory inventory1 = new Inventory();
        inventory1.setId(1);
        inventory1.setName("APPLE1");
        inventory1.setColor(Inventory.COLOR.GREEN);

        inventories.add(inventory);
        inventories.add(inventory1);

        List<Inventory> inventories1 = filterGreenInventory(inventories, Prog1::isGreenInventory);

        Predicate<Inventory> filterByName = (i) -> i.getName().equals("APPLE");

        filterGreenInventory(inventories, (i)-> i.getName().equals("APPLE"));

        filter(inventories, (i) -> i.getColor() == Inventory.COLOR.GREEN);

        filter(List.of("1,2,3"), (String s) -> s.equals("3"));

        //sequence processing
        inventories.stream()
                .filter((Inventory i) -> i.getColor() == Inventory.COLOR.GREEN)
                .collect(Collectors.toList());

        //parallel processing
        inventories.parallelStream()
                .filter((Inventory i) -> i.getColor() == Inventory.COLOR.GREEN)
                .collect(Collectors.toList());
    }

    public static boolean isGreenInventory(Inventory inventory){
        return inventory.getColor() == Inventory.COLOR.GREEN;
    }

    public static List<Inventory> filterGreenInventory(List<Inventory> inventories, Predicate<Inventory> p) {
        List<Inventory> result = new ArrayList<>();
        for (Inventory inventory : inventories) {
            if (p.test(inventory)) {
                result.add(inventory);
            }
        }
        return result;
    }

    static <T> Collection<T> filter(Collection<T> c, Predicate<T> p) {
        List<T> result = new ArrayList<>();
        for (T t : c) {
            if(p.test(t)){
                result.add(t);
            }
        }
        return result;
    }
}

