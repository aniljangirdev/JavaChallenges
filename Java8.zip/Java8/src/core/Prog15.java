package core;

import java.util.ArrayList;
import java.util.List;

public class Prog15 {
    public static void main(String[] args) {
        // boxing example
        List<Integer> integerList = new ArrayList<>();
        for (int i = 0; i < 100; i++) {
            integerList.add(i);
        }
    }
}
