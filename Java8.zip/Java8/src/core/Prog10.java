package core;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.stream.Collectors;

public class Prog10 {
    public static void main(String[] args) throws IOException {

        String result = processFile();

        System.out.println("Result : "+ result);
    }

    static String processFile() throws IOException {
//        File file = new File("./temp/test.txt");
//        InputStream inputStream = new FileInputStream(file);
//        InputStreamReader inputStreamReader = new InputStreamReader(inputStream);

//        File file = new File("./temp/test.txt");
//       FileReader inputStreamReader = new FileReader(file);
//        BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
//        String s = bufferedReader.readLine();

        // using try and resource that has introduce in Java 7
        try (BufferedReader bufferedReader = new BufferedReader(new FileReader("./temp/test.txt"))) {
            return bufferedReader
                    .lines()
                    .collect(Collectors.joining("\n"));
        }
    }
}
