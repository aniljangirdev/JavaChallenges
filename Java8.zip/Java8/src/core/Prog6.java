package core;

import model.Inventory;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Prog6 {
    public static void main(String[] args) {
        // comparator using anonymus class
        List<Inventory> inventories = new ArrayList<>();
        inventories.sort(new Comparator<Inventory>() {
            @Override
            public int compare(Inventory o1, Inventory o2) {
                return o1.getColor().compareTo(o2.getColor());
            }
        });

        //using lambda
        inventories.sort((o1, o2) -> o1.getColor().compareTo(o2.getColor()));

        // create threading using annonymus way
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                System.out.println("Hello World!");
            }
        });

        // thread using lambda
        Thread threadLambda = new Thread(() -> System.out.println("Hello world!"));
        threadLambda.start();


    }
}
