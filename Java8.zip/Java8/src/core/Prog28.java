package core;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class Prog28 {
    public static void main(String[] args) {
        String input = "i am java developer and i love java";
        Map<String, Integer> count = findCount(input);
        System.out.println(count);
    }

    private static Map<String, Integer> findCount(String str) {
        Map<String, Integer> result = new HashMap<>();
        String[] strArray = str.split(" ");
        for (String s : strArray) {
            result.put(s, result.getOrDefault(s, 0) + 1);
        }
        return result.entrySet()
                .stream()
                .sorted(Map.Entry.comparingByValue())
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
                        (a, b) -> a, LinkedHashMap::new));
    }
}