package core;

import model.Inventory;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Supplier;

public class Prog20 {
    public static void main(String[] args) {
        // no argument constructor
        Supplier<Inventory> inventorySupplier = Inventory::new;
        System.out.println(inventorySupplier.get());

        // with single argument constructor
        Function<Integer, Inventory> integerInventoryFunction
                = Inventory::new;
        integerInventoryFunction.apply(10);

        // bind data with one argument
        List<Integer> integers = List.of(1, 2, 3, 4);
        List<Inventory> inventories = map(integers, Inventory::new);
        System.out.println("list " + inventories);

        // bind with two-argument constructor
        BiFunction<Integer, Inventory.COLOR, Inventory> biFunction = Inventory::new;
        Inventory inventory1 = biFunction.apply(1, Inventory.COLOR.GREEN);
        Inventory inventory2 = biFunction.apply(2, Inventory.COLOR.RED);

        List<Inventory> mapResult = map(List.of(inventory1, inventory2), Inventory::new);
        System.out.println(mapResult);

    }
    static List<Inventory> map(List<Integer> list, Function<Integer, Inventory> f) {
        List<Inventory> result = new ArrayList<>();
        for (Integer integer : list) {
            result.add(f.apply(integer));
        }
        return result;
    }

    static List<Inventory> map(List<Inventory> list, BiFunction<Integer, Inventory.COLOR, Inventory> biFunction) {
        List<Inventory> result = new ArrayList<>();
        for (Inventory inventory : list) {
            result.add(biFunction.apply(inventory.getId(), inventory.getColor()));
        }
        return result;
    }



}
