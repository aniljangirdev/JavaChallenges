package core;

public class Prog33 {
    public static void main(String[] args) {
        /*OOP*/
        // primitive -> int, double, long, float
        // objects is instances of class
        // classes are templates for objects
        // encapsulation ->its hiding data within class, preventing outside that class directly interact with it
        //  keeps the programmers in control of access data
        //
        // abstraction -> only showing essential details and keep everything thing hidden
        // eg .laptop -> we can access application and login, without knowing how its internally working
        //
        // inheritance -> its principle that allow classes to derive from other class.

        // polymorphism -> dynamic and static
        // dyna

    }
}

class Laptop{

    private int color;

    private int position;

    public void move() {

    }
}
