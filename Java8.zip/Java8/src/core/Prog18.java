package core;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Prog18 {
    public static void main(String[] args) throws IOException {
        /* using default function interface */
        Function<BufferedReader, String> function = (BufferedReader br) -> br.lines().collect(Collectors.joining("\n"));
        try (BufferedReader bufferedReader = new BufferedReader(new FileReader("./temp/test.txt"))) {
            String ans = function.apply(bufferedReader);
            System.out.println(ans);
        }
    }

}
