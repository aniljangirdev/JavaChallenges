package core;

import model.Inventory;

import java.util.List;
import java.util.stream.Collectors;

public class Prog4 {
    public static void main(String[] args) {
        filterGreenInventory(List.of());
    }

    public static List<Inventory> filterGreenInventory(List<Inventory> inventories){
        return inventories.stream()
                .filter((inventory -> inventory.getColor() == Inventory.COLOR.GREEN))
                .collect(Collectors.toList());
    }

}
