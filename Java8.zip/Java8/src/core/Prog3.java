package core;

import model.Currency;
import model.Transaction;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Prog3 {
    public static void main(String[] args) {



    }

    public void filterByPrice(List<Transaction> transactions) {
        Map<Currency, List<Transaction>> currencyListMap = new HashMap<>();
        for (Transaction transaction : transactions) {
            if(transaction.getPrice() > 1000){
                Currency currency = transaction.getCurrency();
                List<Transaction> transactionsForCurrency = currencyListMap.get(currency);
                if (transactionsForCurrency == null) {
                    transactionsForCurrency = new ArrayList<>();
                    currencyListMap.put(currency, transactionsForCurrency);
                }else {
                    transactionsForCurrency.add(transaction);
                }
            }
        }
    }

    public void filterByCurrency(List<Transaction> transactions){
        transactions.stream()
                .filter((t) -> t.getPrice() > 1000)
                .collect(Collectors.groupingBy(Transaction::getCurrency));
    }

}
