package core;

public class Puzzler {
    public static void main(String[] args) {
        MeaningOfThis meaningOfThis = new MeaningOfThis();
        meaningOfThis.doIt();
    }

    public static class MeaningOfThis{
        public final int value = 6;

        public void doIt(){
            Runnable runnable = new Runnable() {
                public final int value = 5;
                @Override
                public void run() {
                    int value = 10;
                    System.out.println(this.value);
                }
            };
            // here run with new Thread instead of run in main thread using run()
            runnable.run();
        }
    }
}
