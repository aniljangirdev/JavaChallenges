package core;

import java.util.function.Function;

public class Prog24 {
    public static void main(String[] args) {
        /* composite function */

        /* function andThen() method*/
        Function<Integer, Integer> f = no -> no + 1;
        Function<Integer, Integer> g = no -> no * 2;
        Function<Integer, Integer> h = f.andThen(g);
        Integer result = h.apply(1);
        System.out.println(result);

        /* fuction with compose method*/
        Function<Integer, Integer> k = g.compose(f);
        Integer resultK = k.apply(1);
        System.out.println(resultK);
    }
}
