package core;

import model.Inventory;

import java.util.concurrent.Callable;
import java.util.function.Predicate;

public class Prog9 {
    public static void main(String[] args) throws Exception {
        Runnable runnable = () -> System.out.println("Test");
        process(() -> System.out.println("test"));

        // Valid
        execute(()-> {});

        // predicate
        Predicate<String> stringPredicate = (String str) -> str.isEmpty();

        Predicate<Inventory> inventoryPredicate = (Inventory i) -> i.getColor() == Inventory.COLOR.GREEN;

        Callable<String> process = process(Prog9::fetch);

    }

    static Callable<String> fetch(){
        return () -> "test";
    }

    static <T> T process(Callable<T> c) throws Exception {
        return c.call();
    }

    static void process(Runnable r){
        r.run();
    }

    static void execute(Runnable r){
        r.run();
    }
}
