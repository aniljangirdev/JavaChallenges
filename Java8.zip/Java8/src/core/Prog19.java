package core;

import model.Inventory;

import java.security.PrivilegedAction;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.function.*;

public class Prog19 {
    public static void main(String[] args) {
        Callable<Integer> integerCallable = () -> 99;
        PrivilegedAction<Integer> privilegedAction = () -> 42;

        Comparator<Inventory> inventoryComparator
                = Comparator.comparing(Inventory::getName);

        ToIntBiFunction<Inventory, Inventory> inventoryInventoryToIntBiFunction
                = (i1, i2) -> i2.getId().compareTo(i2.getId());

        BiFunction<Inventory, Inventory, Integer> inventoryInventoryIntegerBiFunction
                = (i1, i2) -> i1.getName().compareTo(i2.getName());

        List<String> test1 = List.of("test1", "test2");

        // predicate return boolean
        Predicate<String> stringPredicate = test1::add;
        stringPredicate.test("123");

        //return void
        Consumer<String> b = test1::add;
        b.accept("tets");

        // supplier return string
        Supplier<String> stringSupplier = "test"::toLowerCase;

        Runnable runnable = () -> System.out.println("test");

        int portNumber = 777;
        Runnable r = () -> System.out.println(portNumber);

        BiFunction<String, Integer, String> stringIntegerStringBiFunction =
                String::substring;

        List<String> strings = List.of("1", "2", "3", "4");
        strings.sort(String::compareToIgnoreCase);

        ToIntFunction<String> stringIntegerToIntFunction
                = Integer::parseInt;

        BiPredicate<List<String>, String> listStringBiPredicate
                = List::contains;

        Predicate<String> stringPredicate1 = Prog19::isValidName;

        BiFunction<String, String, Boolean> stringStringBooleanBiFunction
                = String::startsWith;



    }
    static boolean isValidName(String str){
        return Character.isUpperCase(str.charAt(0));
    }

}
