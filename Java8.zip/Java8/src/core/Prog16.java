package core;

import model.IntPredicate;

import java.util.function.IntConsumer;
import java.util.function.IntToLongFunction;
import java.util.function.Predicate;
import java.util.function.ToIntFunction;

public class Prog16 {
    public static void main(String[] args) {
        // autoboxing with java 8

        IntPredicate<Integer> evenNumbers = (i) -> i % 2 == 0;
        evenNumbers.test(10); // true/ no boxing

        Predicate<Integer> oddNumbers = (Integer i) -> i % 2 != 0;
        oddNumbers.test(9); // false/ boxing by Predicate interface



    }
}
