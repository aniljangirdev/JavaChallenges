package patterns;

public class FactoryMethodPattern {
    public static void main(String[] args) {
        IAnimal iAnimal = () -> System.out.println("Bown");
        IAnimalCreator iAnimalCreator = () -> iAnimal;
        iAnimalCreator.createAnimal().speak();
    }
}
interface IAnimal{
    void speak();
}

interface IAnimalCreator{
    IAnimal createAnimal();
}

