package patterns;

public class StrategyPattern {
    public static void main(String[] args) {

        /*definition:
        * The strategy pattern is a common solution for representing a family of algorithms and
          letting you choose among them at runtime.
        * */

        String input = "1234";

        /* here we omit IAllLowercase class using lambda in parameter of validator class */
        Validator validator = new Validator((str) -> str.matches("[a-z]+"));
        boolean validate = validator.isValidate(input);
        System.out.println(validate);

        /* here we omit IsNumeric class using lambda in parameter of validator class */
        Validator validator1 = new Validator((str) -> str.matches("\\d+"));
        boolean validate1 = validator1.isValidate(input);
        System.out.println(validate1);

    }
}

class Validator {
    private final ValidationStrategy validationStrategy;

    Validator(ValidationStrategy validationStrategy) {
        this.validationStrategy = validationStrategy;
    }

    public boolean isValidate(String str) {
        return validationStrategy.execute(str);
    }

}

class IAllLowercase implements ValidationStrategy {
    @Override
    public boolean execute(String s) {
        return s.matches("[a-z]+");
    }
}

class ISNumeric implements ValidationStrategy {

    @Override
    public boolean execute(String s) {
        return s.matches("\\d+");
    }
}

interface ValidationStrategy {
    boolean execute(String s);
}
