package patterns;

import java.util.Map;
import java.util.function.Supplier;

public class FactoryPattern {

    static Map<String, Supplier<Product>> map = Map.of(
            "loan", Loan::new,
            "stock", Stock::new
    );


    public static void main(String[] args) {
        /*The factory design pattern lets you create objects without exposing the instantiation
        logic to the client*/

        Product loan = ProductFactory.createProduct("loan");

        /* using lambda*/
        Product loan1 = createProduct("loan");

        map.put("", null);
    }

    public static Product createProduct(String name) {
        Supplier<Product> p = map.get(name);
        if (p != null) return p.get();
        throw new IllegalArgumentException("No such product : " + name);
    }


}

class ProductFactory {
    public static Product createProduct(String name) {
        switch (name) {
            case "loan":
                return new Loan();
            case "stock":
                return new Stock();
            default:
                throw new RuntimeException("No Such product " + name);
        }
    }
}

class Loan extends Product {

}

class Stock extends Product {

}

class Product {

}