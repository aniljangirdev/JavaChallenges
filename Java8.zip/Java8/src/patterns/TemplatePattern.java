package patterns;

import core.SingletonDB;
import model.Customer;

import java.util.function.Consumer;

public class TemplatePattern {
    public static void main(String[] args) {
        /*definition
        * The template method design pattern is a common solution when you need to
        * represent the outline of an algorithm and have the additional flexibility to change certain
          parts of it.
        * In other words, the template
          method pattern is useful when you find yourself saying “I’d love to use this algorithm,
          but I need to change a few lines so it does what I want.”
        *
        * */

        OnlineBankingLambda onlineBankingLambda = new OnlineBankingLambda();
        onlineBankingLambda.processCustomer(10, System.out::println);

        /*
        * This example shows how lambda expressions can help you remove the boilerplate
           inherent to design patterns.
* */

    }
}

abstract class OnlineBanking{
    public void processCustomer(int id){
        Customer customer = SingletonDB.getInstance().getCustomer(id);
        makeCustomHappy(customer);
    }
    abstract void makeCustomHappy(Customer customer);
}

class OnlineBankingLambda{
    public void processCustomer(int id, Consumer<Customer> customerConsumer) {
        Customer customer = SingletonDB.getInstance().getCustomer(id);
        customerConsumer.accept(customer);
    }
}


