package patterns;

public class BuilderPattern {
    public static void main(String[] args) {
        BackAccount backAccount = new BackAccount.BankAccountBuilder()
                .withEmail("Amil")
                .wantNewsletter(true)
                .build();
    }
}

class BackAccount {
    private String name;
    private String accountNumber;
    private String email;
    private boolean newsletter;

    public BackAccount(BankAccountBuilder bankAccountBuilder) {

    }

    // constructors/getters

    public static class BankAccountBuilder {
        private String name;
        private String accountNumber;
        private String email;
        private boolean newsletter;

        public BankAccountBuilder() {

        }

        public BankAccountBuilder(String name, String accountNumber) {
            this.name = name;
            this.accountNumber = accountNumber;
        }

        public BankAccountBuilder withEmail(String email) {
            this.email = email;
            return this;
        }

        public BankAccountBuilder wantNewsletter(boolean newsletter) {
            this.newsletter = newsletter;
            return this;
        }

        public BackAccount build() {
            return new BackAccount(this);
        }
    }

}
