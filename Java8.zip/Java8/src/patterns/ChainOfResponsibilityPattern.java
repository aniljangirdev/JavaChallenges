package patterns;

import java.util.function.Function;
import java.util.function.UnaryOperator;

public class ChainOfResponsibilityPattern {
    public static void main(String[] args) {

        /*The chain of responsibility pattern is a common solution to create a chain of processing objects (such as a chain of operations). One processing object may do some work
        and pass the result to another object, which also does some work and passes it on to
        yet another processing object, and so on.
         Generally, this pattern is implemented by defining an abstract class representing
        a processing object that defines a field to keep track of a successor. When it finishes
        its work, the processing object hands over its work to its successor
        */

        ProcessingObject<String> p1 = new HeaderTextProcessing();
        ProcessingObject<String> p2 = new SpellingTextProcessing();

        p1.setSuccessor(p2);

        String result = p1.handle("good labda !");

        System.out.println(result);

        /* using lambda expressions*/
        UnaryOperator<String> p3 = (String input) -> "this is labda by " + input;
        UnaryOperator<String> p4 = (String input) -> input.replaceAll("labda", "Lambda");

        Function<String, String> pipeline = p3.andThen(p4);

        String apply = pipeline.apply("this is good book of labda");
        System.out.println(apply);
    }

}

class SpellingTextProcessing extends ProcessingObject<String> {

    @Override
    protected String handleWork(String input) {
        return input.replaceAll("labda", "Lambda");
    }
}

class HeaderTextProcessing extends ProcessingObject<String> {

    @Override
    protected String handleWork(String input) {
        return "this is header by " + input;
    }
}

abstract class ProcessingObject<T> {
    protected ProcessingObject<T> successor;

    public void setSuccessor(ProcessingObject<T> successor) {
        this.successor = successor;
    }

    public T handle(T input) {
        T r = handleWork(input);
        if (successor != null) {
            return successor.handle(r);
        }
        return r;
    }

    abstract protected T handleWork(T input);
}
