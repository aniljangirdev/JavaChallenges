package patterns;

public class SingletonPattern {
    private SingletonPattern(){
        // can't to create object of class
    }

    private static class SingletonHolder{
        private static final SingletonPattern INSTANCE = new SingletonPattern();
    }

    private SingletonPattern getInstance() {
        return SingletonHolder.INSTANCE;
    }

    private void makeConnection(){

    }

    public static void main(String[] args) {
        SingletonPattern instance = SingletonHolder.INSTANCE.getInstance();
        instance.makeConnection();
    }
}


