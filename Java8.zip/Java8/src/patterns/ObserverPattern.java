package patterns;

import java.util.ArrayList;
import java.util.List;

public class ObserverPattern {
    public static void main(String[] args) {
        /*
        * The observer design pattern is a common solution when an object (called the subject)
        needs to automatically notify a list of other objects (called observers) when some event
        happens (such as a state change). You typically come across this pattern when working
        with GUI applications. You register a set of observers on a GUI component such as a
        button. If the button is clicked, the observers are notified and can execute a specific
        action. But the observer pattern isn’t limited to GUIs. The observer design pattern is
        * also suitable in a situation in which several traders (observers) want to react to the
        change of price of a stock (subject)*/

        /* declare different observers*/

        Observer GardianObserver = (tweet -> {
            if (tweet != null && tweet.contains("queen")) {
                System.out.println("breaking new from london! "+ tweet);
            }
        });

        Feed feed = new Feed();
        feed.registerObserver(new NYTimes());
        feed.registerObserver(GardianObserver);
        feed.notifyObservers("favorite book modern java in action :queen");
    }
}

class NYTimes implements Observer{

    @Override
    public void notify(String tweet) {
        if (tweet != null && tweet.contains("money")) {
            System.out.println("Breaking new in NY! " + tweet);
        }
    }
}

class Feed implements Subject {

    private final List<Observer> observers = new ArrayList<>();

    @Override
    public void registerObserver(Observer observer) {
        this.observers.add(observer);
    }

    @Override
    public void notifyObservers(String tweet) {
        observers.forEach(o -> o.notify(tweet));
    }
}

interface Observer{
    void notify(String tweet);
}

interface Subject{
    void registerObserver(Observer observer);
    void notifyObservers(String tweet);
}
